package com.example.data.ai

import com.example.domain.DietaryPreference
import com.example.domain.DifficultyLevel
import com.example.domain.MealCategory
import com.example.domain.MeasurementSystem
import com.example.domain.NutritionInfo
import com.example.domain.Recipe
import com.example.domain.RecipeIngredient
import com.example.domain.ShoppingCategory
import com.google.firebase.ai.type.Schema
import org.json.JSONObject
import java.util.UUID

object RecipeJsonParser {

    val recipesResponseSchema: Schema = Schema.obj(
        properties = mapOf(
            "recipes" to Schema.array(
                description = "Up to 3 complete, practical home-cooked recipes",
                items = Schema.obj(
                    properties = mapOf(
                        "name" to Schema.string(description = "Recipe title"),
                        "description" to Schema.string(description = "Short 1-2 sentence description"),
                        "prepTimeMinutes" to Schema.integer(description = "Preparation time in minutes"),
                        "cookTimeMinutes" to Schema.integer(description = "Cooking time in minutes"),
                        "servings" to Schema.integer(description = "Number of servings (1 to 12)"),
                        "difficulty" to Schema.enumeration(
                            values = listOf("Easy", "Medium", "Hard"),
                            description = "Recipe difficulty level"
                        ),
                        "mealCategory" to Schema.enumeration(
                            values = listOf("Breakfast", "Lunch", "Dinner", "Snacks"),
                            description = "Primary meal category"
                        ),
                        "ingredients" to Schema.array(
                            description = "Ingredients with exact numeric quantities and units",
                            items = Schema.obj(
                                properties = mapOf(
                                    "name" to Schema.string(description = "Ingredient name and prep note"),
                                    "amount" to Schema.double(description = "Positive numeric quantity"),
                                    "unit" to Schema.string(description = "Measurement unit such as cups, tbsp, tsp, oz, lb, g, kg, ml, l, or whole/cloves/large"),
                                    "category" to Schema.enumeration(
                                        values = listOf("Produce", "Dairy", "Meat", "Pantry", "Other"),
                                        description = "Grocery aisle category"
                                    )
                                )
                            )
                        ),
                        "steps" to Schema.array(
                            description = "Clear numbered step-by-step cooking instructions",
                            items = Schema.string()
                        ),
                        "nutrition" to Schema.obj(
                            description = "Estimated nutrition per serving",
                            properties = mapOf(
                                "calories" to Schema.integer(description = "Estimated kcal per serving"),
                                "proteinGrams" to Schema.integer(description = "Estimated protein in grams"),
                                "carbsGrams" to Schema.integer(description = "Estimated carbohydrates in grams"),
                                "fatGrams" to Schema.integer(description = "Estimated fat in grams"),
                                "fiberGrams" to Schema.integer(description = "Estimated fiber in grams")
                            )
                        ),
                        "allergenInfo" to Schema.array(
                            description = "Common allergens present or potential cross-contamination notes",
                            items = Schema.string()
                        ),
                        "substitutions" to Schema.array(
                            description = "Helpful ingredient substitutions",
                            items = Schema.string()
                        ),
                        "storageSuggestions" to Schema.string(
                            description = "Safe fridge/freezer storage and reheating guidance"
                        )
                    )
                )
            )
        )
    )

    fun parseAndValidate(
        jsonString: String,
        measurementSystem: MeasurementSystem,
        dietaryTag: DietaryPreference
    ): List<Recipe> {
        val root = JSONObject(jsonString)
        val recipesArray = root.optJSONArray("recipes")
            ?: throw IllegalStateException("Recipe response did not include a recipes list.")

        val validRecipes = mutableListOf<Recipe>()
        val count = recipesArray.length().coerceAtMost(3)

        for (i in 0 until count) {
            val item = recipesArray.optJSONObject(i) ?: continue
            val parsed = parseSingleRecipe(item, measurementSystem, dietaryTag)
            if (parsed != null) {
                validRecipes.add(parsed)
            }
        }

        if (validRecipes.isEmpty()) {
            throw IllegalStateException("Generated recipes failed validation checks. Please try again.")
        }

        return validRecipes
    }

    private fun parseSingleRecipe(
        obj: JSONObject,
        measurementSystem: MeasurementSystem,
        dietaryTag: DietaryPreference
    ): Recipe? {
        val name = obj.optString("name", "").trim()
        val description = obj.optString("description", "").trim()
        if (name.isBlank() || description.isBlank()) return null

        val prepTime = obj.optInt("prepTimeMinutes", -1)
        val cookTime = obj.optInt("cookTimeMinutes", -1)
        val servings = obj.optInt("servings", -1)
        if (prepTime < 0 || prepTime > 600 || cookTime < 0 || cookTime > 600) return null
        if (servings !in 1..24) return null

        val ingredientsArray = obj.optJSONArray("ingredients") ?: return null
        val ingredients = mutableListOf<RecipeIngredient>()
        for (j in 0 until ingredientsArray.length()) {
            val ingObj = ingredientsArray.optJSONObject(j) ?: continue
            val ingName = ingObj.optString("name", "").trim()
            val amount = ingObj.optDouble("amount", Double.NaN)
            val unit = ingObj.optString("unit", "").trim()
            val catStr = ingObj.optString("category", "Other")
            if (ingName.isBlank() || amount.isNaN() || amount.isInfinite() || amount <= 0.0) {
                continue
            }
            ingredients.add(
                RecipeIngredient(
                    name = ingName,
                    amount = amount,
                    unit = unit,
                    category = parseCategory(catStr)
                )
            )
        }
        if (ingredients.isEmpty()) return null

        val stepsArray = obj.optJSONArray("steps") ?: return null
        val steps = (0 until stepsArray.length())
            .map { stepsArray.optString(it, "").trim() }
            .filter { it.isNotBlank() }
        if (steps.isEmpty()) return null

        val nutritionObj = obj.optJSONObject("nutrition") ?: return null
        val calories = nutritionObj.optInt("calories", -1)
        val protein = nutritionObj.optInt("proteinGrams", -1)
        val carbs = nutritionObj.optInt("carbsGrams", -1)
        val fat = nutritionObj.optInt("fatGrams", -1)
        val fiber = nutritionObj.optInt("fiberGrams", 0).coerceAtLeast(0)
        if (calories < 0 || protein < 0 || carbs < 0 || fat < 0) return null

        val allergenArray = obj.optJSONArray("allergenInfo")
        val allergens = if (allergenArray != null) {
            (0 until allergenArray.length())
                .map { allergenArray.optString(it, "").trim() }
                .filter { it.isNotBlank() }
        } else emptyList()

        val subsArray = obj.optJSONArray("substitutions")
        val substitutions = if (subsArray != null) {
            (0 until subsArray.length())
                .map { subsArray.optString(it, "").trim() }
                .filter { it.isNotBlank() }
        } else emptyList()

        val storage = obj.optString("storageSuggestions", "").trim()
        if (storage.isBlank()) return null

        val difficulty = when (obj.optString("difficulty", "Easy").trim().lowercase()) {
            "medium" -> DifficultyLevel.MEDIUM
            "hard" -> DifficultyLevel.HARD
            else -> DifficultyLevel.EASY
        }

        val mealCategory = when (obj.optString("mealCategory", "Dinner").trim().lowercase()) {
            "breakfast" -> MealCategory.BREAKFAST
            "lunch" -> MealCategory.LUNCH
            "snack", "snacks" -> MealCategory.SNACK
            else -> MealCategory.DINNER
        }

        return Recipe(
            id = UUID.randomUUID().toString(),
            name = name,
            description = description,
            prepTimeMinutes = prepTime,
            cookTimeMinutes = cookTime,
            servings = servings,
            ingredients = ingredients,
            steps = steps,
            difficulty = difficulty,
            nutrition = NutritionInfo(
                calories = calories,
                proteinGrams = protein,
                carbsGrams = carbs,
                fatGrams = fat,
                fiberGrams = fiber
            ),
            allergenInfo = if (allergens.isEmpty()) {
                listOf("Check all packaged ingredient labels carefully for potential allergens.")
            } else allergens,
            substitutions = substitutions,
            storageSuggestions = storage,
            mealCategory = mealCategory,
            dietaryTags = if (dietaryTag == DietaryPreference.NONE) emptyList() else listOf(dietaryTag),
            measurementSystem = measurementSystem,
            isAiGenerated = true,
            isRecentGenerated = true
        )
    }

    private fun parseCategory(value: String): ShoppingCategory {
        return when (value.trim().lowercase()) {
            "produce" -> ShoppingCategory.PRODUCE
            "dairy" -> ShoppingCategory.DAIRY
            "meat" -> ShoppingCategory.MEAT
            "pantry" -> ShoppingCategory.PANTRY
            else -> ShoppingCategory.OTHER
        }
    }
}
