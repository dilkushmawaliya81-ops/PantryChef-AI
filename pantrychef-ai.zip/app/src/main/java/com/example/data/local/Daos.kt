package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes WHERE isFavourite = 1 ORDER BY createdAt DESC")
    fun observeFavourites(): Flow<List<RecipeEntity>>

    @Query("SELECT * FROM recipes WHERE isRecentGenerated = 1 ORDER BY createdAt DESC LIMIT 30")
    fun observeRecentGenerated(): Flow<List<RecipeEntity>>

    @Query("SELECT * FROM recipes WHERE lastViewedAt > 0 ORDER BY lastViewedAt DESC LIMIT 12")
    fun observeRecentlyViewed(): Flow<List<RecipeEntity>>

    @Query("SELECT * FROM recipes WHERE id = :id LIMIT 1")
    suspend fun getRecipeById(id: String): RecipeEntity?

    @Query("SELECT * FROM recipes WHERE id = :id LIMIT 1")
    fun observeRecipeById(id: String): Flow<RecipeEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecipe(entity: RecipeEntity)

    @Query("UPDATE recipes SET isFavourite = :isFavourite WHERE id = :id")
    suspend fun setFavourite(id: String, isFavourite: Boolean)

    @Query("UPDATE recipes SET lastViewedAt = :viewedAt WHERE id = :id")
    suspend fun updateLastViewed(id: String, viewedAt: Long)

    @Query("SELECT * FROM recipes")
    suspend fun getAllStoredRecipes(): List<RecipeEntity>
}

@Dao
interface MealPlanDao {
    @Query("SELECT * FROM meal_plans")
    fun observeAllMealPlans(): Flow<List<MealPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMealPlan(entry: MealPlanEntity)

    @Query("DELETE FROM meal_plans WHERE dayOfWeek = :dayOfWeek AND mealSlot = :mealSlot")
    suspend fun deleteMealSlot(dayOfWeek: String, mealSlot: String)

    @Query("DELETE FROM meal_plans")
    suspend fun clearAllMealPlans()
}

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM shopping_items ORDER BY isChecked ASC, createdAt DESC")
    fun observeAllItems(): Flow<List<ShoppingItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertItem(item: ShoppingItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertItems(items: List<ShoppingItemEntity>)

    @Update
    suspend fun updateItem(item: ShoppingItemEntity)

    @Query("UPDATE shopping_items SET isChecked = :isChecked WHERE id = :id")
    suspend fun setItemChecked(id: String, isChecked: Boolean)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteItemById(id: String)

    @Query("DELETE FROM shopping_items WHERE isChecked = 1")
    suspend fun clearCheckedItems()
}
