package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.DietaryPreference
import com.example.domain.EnglishVariant
import com.example.domain.MeasurementSystem
import com.example.domain.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pantry_chef_prefs")

class PreferencesDataStore(private val context: Context) {

    private object Keys {
        val MEASUREMENT_SYSTEM = stringPreferencesKey("measurement_system")
        val ENGLISH_VARIANT = stringPreferencesKey("english_variant")
        val DIETARY_PREFERENCE = stringPreferencesKey("dietary_preference")
        val SELECTED_ALLERGENS = stringSetPreferencesKey("selected_allergens")
        val CUSTOM_ALLERGIES = stringPreferencesKey("custom_allergies")
        val DAILY_AI_COUNT = intPreferencesKey("daily_ai_count")
        val LAST_AI_USAGE_DATE = stringPreferencesKey("last_ai_usage_date")
    }

    private fun defaultMeasurementForLocale(): MeasurementSystem {
        val country = Locale.getDefault().country.uppercase(Locale.ROOT)
        return if (country == "US") MeasurementSystem.US_CUSTOMARY else MeasurementSystem.METRIC
    }

    private fun defaultEnglishForLocale(): EnglishVariant {
        val country = Locale.getDefault().country.uppercase(Locale.ROOT)
        return if (country == "GB" || country == "UK") EnglishVariant.UK else EnglishVariant.US
    }

    fun todayDateKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val measurement = prefs[Keys.MEASUREMENT_SYSTEM]?.let {
            runCatching { MeasurementSystem.valueOf(it) }.getOrNull()
        } ?: defaultMeasurementForLocale()

        val english = prefs[Keys.ENGLISH_VARIANT]?.let {
            runCatching { EnglishVariant.valueOf(it) }.getOrNull()
        } ?: defaultEnglishForLocale()

        val dietary = prefs[Keys.DIETARY_PREFERENCE]?.let {
            runCatching { DietaryPreference.valueOf(it) }.getOrNull()
        } ?: DietaryPreference.NONE

        val selectedAllergens = prefs[Keys.SELECTED_ALLERGENS] ?: emptySet()
        val customAllergiesRaw = prefs[Keys.CUSTOM_ALLERGIES].orEmpty()
        val customAllergies = customAllergiesRaw
            .split("|")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val today = todayDateKey()
        val storedDate = prefs[Keys.LAST_AI_USAGE_DATE].orEmpty()
        val dailyCount = if (storedDate == today) prefs[Keys.DAILY_AI_COUNT] ?: 0 else 0

        UserPreferences(
            measurementSystem = measurement,
            englishVariant = english,
            dietaryPreference = dietary,
            selectedAllergens = selectedAllergens,
            customAllergies = customAllergies,
            dailyAiCount = dailyCount,
            lastAiUsageDate = today
        )
    }

    suspend fun setMeasurementSystem(system: MeasurementSystem) {
        context.dataStore.edit { it[Keys.MEASUREMENT_SYSTEM] = system.name }
    }

    suspend fun setEnglishVariant(variant: EnglishVariant) {
        context.dataStore.edit { it[Keys.ENGLISH_VARIANT] = variant.name }
    }

    suspend fun setDietaryPreference(preference: DietaryPreference) {
        context.dataStore.edit { it[Keys.DIETARY_PREFERENCE] = preference.name }
    }

    suspend fun toggleCommonAllergen(allergen: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SELECTED_ALLERGENS] ?: emptySet()
            prefs[Keys.SELECTED_ALLERGENS] = if (allergen in current) current - allergen else current + allergen
        }
    }

    suspend fun addCustomAllergy(allergy: String) {
        val cleaned = allergy.trim()
        if (cleaned.isEmpty()) return
        context.dataStore.edit { prefs ->
            val existing = prefs[Keys.CUSTOM_ALLERGIES].orEmpty()
                .split("|")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            if (existing.none { it.equals(cleaned, ignoreCase = true) }) {
                prefs[Keys.CUSTOM_ALLERGIES] = (existing + cleaned).joinToString("|")
            }
        }
    }

    suspend fun removeCustomAllergy(allergy: String) {
        context.dataStore.edit { prefs ->
            val updated = prefs[Keys.CUSTOM_ALLERGIES].orEmpty()
                .split("|")
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.equals(allergy, ignoreCase = true) }
            prefs[Keys.CUSTOM_ALLERGIES] = updated.joinToString("|")
        }
    }

    suspend fun incrementDailyAiUsage() {
        val today = todayDateKey()
        context.dataStore.edit { prefs ->
            val storedDate = prefs[Keys.LAST_AI_USAGE_DATE].orEmpty()
            val currentCount = if (storedDate == today) prefs[Keys.DAILY_AI_COUNT] ?: 0 else 0
            prefs[Keys.LAST_AI_USAGE_DATE] = today
            prefs[Keys.DAILY_AI_COUNT] = currentCount + 1
        }
    }
}
