package com.example.data.repository

import com.example.data.ai.AiRecipeResult
import com.example.data.ai.FirebaseAiRecipeService
import com.example.data.local.MealPlanDao
import com.example.data.local.MealPlanEntity
import com.example.data.local.PreferencesDataStore
import com.example.data.local.RecipeDao
import com.example.data.local.RecipeEntity
import com.example.data.local.RecipeSerialization
import com.example.data.local.ShoppingItemEntity
import com.example.data.local.ShoppingListDao
import com.example.domain.DayOfWeekSlot
import com.example.domain.DietaryPreference
import com.example.domain.EnglishVariant
import com.example.domain.MealCategory
import com.example.domain.MealPlanEntry
import com.example.domain.MealSlotType
import com.example.domain.MeasurementSystem
import com.example.domain.Recipe
import com.example.domain.SampleRecipes
import com.example.domain.ShoppingCategory
import com.example.domain.ShoppingItem
import com.example.domain.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

class PantryChefRepository(
    private val recipeDao: RecipeDao,
    private val mealPlanDao: MealPlanDao,
    private val shoppingListDao: ShoppingListDao,
    private val preferencesDataStore: PreferencesDataStore,
    private val aiRecipeService: FirebaseAiRecipeService
) {

    val preferencesFlow: Flow<UserPreferences> = preferencesDataStore.preferencesFlow

    val favouritesFlow: Flow<List<Recipe>> = recipeDao.observeFavourites().map { entities ->
        entities.mapNotNull { it.toDomain() }
    }

    val recentGeneratedFlow: Flow<List<Recipe>> = recipeDao.observeRecentGenerated().map { entities ->
        entities.mapNotNull { it.toDomain() }
    }

    val recentlyViewedFlow: Flow<List<Recipe>> = recipeDao.observeRecentlyViewed().map { entities ->
        entities.mapNotNull { it.toDomain() }
    }

    val mealPlanFlow: Flow<List<MealPlanEntry>> = mealPlanDao.observeAllMealPlans().map { entities ->
        entities.mapNotNull { entity ->
            val day = runCatching { DayOfWeekSlot.valueOf(entity.dayOfWeek) }.getOrNull() ?: return@mapNotNull null
            val slot = runCatching { MealSlotType.valueOf(entity.mealSlot) }.getOrNull() ?: return@mapNotNull null
            val cat = runCatching { MealCategory.valueOf(entity.mealCategory) }.getOrDefault(MealCategory.DINNER)
            MealPlanEntry(
                id = entity.id,
                dayOfWeek = day,
                mealSlot = slot,
                recipeId = entity.recipeId,
                recipeName = entity.recipeName,
                mealCategory = cat,
                totalTimeMinutes = entity.totalTimeMinutes
            )
        }
    }

    val shoppingListFlow: Flow<List<ShoppingItem>> = shoppingListDao.observeAllItems().map { entities ->
        entities.map { entity ->
            ShoppingItem(
                id = entity.id,
                name = entity.name,
                quantityText = entity.quantityText,
                category = runCatching { ShoppingCategory.valueOf(entity.category) }
                    .getOrDefault(ShoppingCategory.OTHER),
                isChecked = entity.isChecked,
                recipeSource = entity.recipeSource,
                createdAt = entity.createdAt
            )
        }
    }

    suspend fun generateRecipes(
        ingredients: List<String>,
        mealCategory: MealCategory?
    ): AiRecipeResult {
        val prefs = preferencesDataStore.preferencesFlow.first()
        if (prefs.dailyAiCount >= UserPreferences.DAILY_AI_LIMIT) {
            return AiRecipeResult.Error(
                message = "You have used all ${UserPreferences.DAILY_AI_LIMIT} free daily AI recipe generations for today. Explore your saved favourites or offline sample recipes below.",
                isQuotaOrOffline = true
            )
        }

        val result = aiRecipeService.generateRecipes(ingredients, mealCategory, prefs)
        if (result is AiRecipeResult.Success) {
            preferencesDataStore.incrementDailyAiUsage()
            result.recipes.forEach { recipe ->
                recipeDao.upsertRecipe(recipe.toEntity(isFavourite = false, isRecentGenerated = true))
            }
        }
        return result
    }

    suspend fun getRecipeById(id: String): Recipe? {
        val stored = recipeDao.getRecipeById(id)?.toDomain()
        if (stored != null) return stored
        return SampleRecipes.all.find { it.id == id }
    }

    fun observeRecipeById(id: String): Flow<Recipe?> {
        return recipeDao.observeRecipeById(id).map { entity ->
            entity?.toDomain() ?: SampleRecipes.all.find { it.id == id }
        }
    }

    suspend fun markRecipeViewed(recipe: Recipe) {
        val existing = recipeDao.getRecipeById(recipe.id)
        val now = System.currentTimeMillis()
        if (existing != null) {
            recipeDao.updateLastViewed(recipe.id, now)
        } else {
            recipeDao.upsertRecipe(
                recipe.copy(lastViewedAt = now).toEntity(
                    isFavourite = recipe.isFavourite,
                    isRecentGenerated = recipe.isRecentGenerated
                )
            )
        }
    }

    suspend fun toggleFavourite(recipe: Recipe) {
        val existing = recipeDao.getRecipeById(recipe.id)
        if (existing != null) {
            recipeDao.setFavourite(recipe.id, !existing.isFavourite)
        } else {
            recipeDao.upsertRecipe(
                recipe.copy(isFavourite = true).toEntity(
                    isFavourite = true,
                    isRecentGenerated = recipe.isRecentGenerated
                )
            )
        }
    }

    suspend fun assignMealPlan(day: DayOfWeekSlot, slot: MealSlotType, recipe: Recipe) {
        if (recipeDao.getRecipeById(recipe.id) == null) {
            recipeDao.upsertRecipe(
                recipe.toEntity(
                    isFavourite = recipe.isFavourite,
                    isRecentGenerated = recipe.isRecentGenerated
                )
            )
        }
        val entity = MealPlanEntity(
            id = "${day.name}_${slot.name}",
            dayOfWeek = day.name,
            mealSlot = slot.name,
            recipeId = recipe.id,
            recipeName = recipe.name,
            mealCategory = recipe.mealCategory.name,
            totalTimeMinutes = recipe.totalTimeMinutes
        )
        mealPlanDao.upsertMealPlan(entity)
    }

    suspend fun removeMealPlan(day: DayOfWeekSlot, slot: MealSlotType) {
        mealPlanDao.deleteMealSlot(day.name, slot.name)
    }

    suspend fun addShoppingItem(
        name: String,
        quantityText: String,
        category: ShoppingCategory,
        recipeSource: String = ""
    ) {
        val entity = ShoppingItemEntity(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            quantityText = quantityText.trim(),
            category = category.name,
            isChecked = false,
            recipeSource = recipeSource
        )
        shoppingListDao.upsertItem(entity)
    }

    suspend fun addShoppingItemsBatch(items: List<ShoppingItem>) {
        if (items.isEmpty()) return
        shoppingListDao.upsertItems(
            items.map { item ->
                ShoppingItemEntity(
                    id = item.id,
                    name = item.name,
                    quantityText = item.quantityText,
                    category = item.category.name,
                    isChecked = item.isChecked,
                    recipeSource = item.recipeSource,
                    createdAt = item.createdAt
                )
            }
        )
    }

    suspend fun updateShoppingItem(item: ShoppingItem) {
        shoppingListDao.updateItem(
            ShoppingItemEntity(
                id = item.id,
                name = item.name,
                quantityText = item.quantityText,
                category = item.category.name,
                isChecked = item.isChecked,
                recipeSource = item.recipeSource,
                createdAt = item.createdAt
            )
        )
    }

    suspend fun toggleShoppingItemChecked(id: String, isChecked: Boolean) {
        shoppingListDao.setItemChecked(id, isChecked)
    }

    suspend fun deleteShoppingItem(id: String) {
        shoppingListDao.deleteItemById(id)
    }

    suspend fun clearCheckedShoppingItems() {
        shoppingListDao.clearCheckedItems()
    }

    suspend fun setMeasurementSystem(system: MeasurementSystem) =
        preferencesDataStore.setMeasurementSystem(system)

    suspend fun setEnglishVariant(variant: EnglishVariant) =
        preferencesDataStore.setEnglishVariant(variant)

    suspend fun setDietaryPreference(preference: DietaryPreference) =
        preferencesDataStore.setDietaryPreference(preference)

    suspend fun toggleCommonAllergen(allergen: String) =
        preferencesDataStore.toggleCommonAllergen(allergen)

    suspend fun addCustomAllergy(allergy: String) =
        preferencesDataStore.addCustomAllergy(allergy)

    suspend fun removeCustomAllergy(allergy: String) =
        preferencesDataStore.removeCustomAllergy(allergy)

    private fun RecipeEntity.toDomain(): Recipe? {
        return RecipeSerialization.fromJson(
            jsonString = recipeJson,
            isFavourite = isFavourite,
            isRecentGenerated = isRecentGenerated,
            lastViewedAt = lastViewedAt
        )
    }

    private fun Recipe.toEntity(
        isFavourite: Boolean,
        isRecentGenerated: Boolean
    ): RecipeEntity {
        return RecipeEntity(
            id = id,
            name = name,
            mealCategory = mealCategory.name,
            recipeJson = RecipeSerialization.toJson(this),
            isFavourite = isFavourite,
            isRecentGenerated = isRecentGenerated,
            lastViewedAt = lastViewedAt,
            createdAt = createdAt
        )
    }
}
