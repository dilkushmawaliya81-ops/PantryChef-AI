package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mealCategory: String,
    val recipeJson: String,
    val isFavourite: Boolean = false,
    val isRecentGenerated: Boolean = false,
    val lastViewedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "meal_plans",
    indices = [Index(value = ["dayOfWeek", "mealSlot"], unique = true)]
)
data class MealPlanEntity(
    @PrimaryKey val id: String,
    val dayOfWeek: String,
    val mealSlot: String,
    val recipeId: String,
    val recipeName: String,
    val mealCategory: String,
    val totalTimeMinutes: Int
)

@Entity(tableName = "shopping_items")
data class ShoppingItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val quantityText: String,
    val category: String,
    val isChecked: Boolean = false,
    val recipeSource: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
