package com.example.data.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.domain.DietaryPreference
import com.example.domain.EnglishVariant
import com.example.domain.MealCategory
import com.example.domain.MeasurementSystem
import com.example.domain.Recipe
import com.example.domain.UserPreferences
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

private const val TAG = "FirebaseAiRecipeService"
private const val MODEL_NAME = "gemini-3.8-flash"

sealed interface AiRecipeResult {
    data class Success(val recipes: List<Recipe>) : AiRecipeResult
    data class Error(val message: String, val isQuotaOrOffline: Boolean = false) : AiRecipeResult
}

class FirebaseAiRecipeService(private val context: Context) {

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = RecipeJsonParser.recipesResponseSchema
                temperature = 0.7f
            }
        )
    }

    suspend fun generateRecipes(
        ingredients: List<String>,
        mealCategory: MealCategory?,
        preferences: UserPreferences
    ): AiRecipeResult {
        if (!isNetworkAvailable()) {
            return AiRecipeResult.Error(
                message = "You appear to be offline. Connect to the internet to generate AI recipes, or browse offline sample recipes below.",
                isQuotaOrOffline = true
            )
        }

        val prompt = buildPrompt(ingredients, mealCategory, preferences)

        return try {
            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }
            val jsonText = response.text
            if (jsonText.isNullOrBlank()) {
                return AiRecipeResult.Error("The AI model returned an empty response. Please try again.")
            }

            val parsedRecipes = RecipeJsonParser.parseAndValidate(
                jsonString = jsonText,
                measurementSystem = preferences.measurementSystem,
                dietaryTag = preferences.dietaryPreference
            )
            AiRecipeResult.Success(parsedRecipes)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Recipe generation timed out", e)
            AiRecipeResult.Error("Request timed out after 60 seconds. Check your connection and retry.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI recipe generation failed", e)
            val rawMsg = e.localizedMessage.orEmpty()
            val friendly = when {
                rawMsg.contains("quota", ignoreCase = true) ||
                    rawMsg.contains("429") ||
                    rawMsg.contains("resource_exhausted", ignoreCase = true) ->
                    "The free-tier AI quota is temporarily busy. Please try again shortly or browse our offline sample recipes."
                rawMsg.contains("403") || rawMsg.contains("appcheck", ignoreCase = true) ->
                    "App verification (App Check) failed for this AI request. You can still use all offline sample recipes, meal plans, and shopping lists."
                else ->
                    "Unable to generate AI recipes right now (${rawMsg.ifBlank { "network or service error" }}). Please retry or explore offline sample recipes."
            }
            AiRecipeResult.Error(friendly, isQuotaOrOffline = true)
        }
    }

    private fun buildPrompt(
        ingredients: List<String>,
        mealCategory: MealCategory?,
        preferences: UserPreferences
    ): String {
        val unitInstruction = when (preferences.measurementSystem) {
            MeasurementSystem.US_CUSTOMARY ->
                "Use US Customary units exclusively (cups, tbsp, tsp, oz, lb, °F)."
            MeasurementSystem.METRIC ->
                "Use Metric units exclusively (g, kg, ml, l, °C)."
        }

        val spellingInstruction = when (preferences.englishVariant) {
            EnglishVariant.US -> "Use US English spelling and culinary terms."
            EnglishVariant.UK -> "Use UK English spelling and culinary terms (e.g. courgette, coriander, millilitres, grams, °C)."
        }

        val categoryInstruction = mealCategory?.let {
            "Focus on ${it.displayName} recipes."
        } ?: "Choose an appropriate meal category (Breakfast, Lunch, Dinner, or Snacks) for each recipe."

        val allergiesText = if (preferences.allAllergies.isEmpty()) {
            "None specified"
        } else {
            preferences.allAllergies.joinToString(", ")
        }

        return buildString {
            appendLine("You are PantryChef AI, a practical home-cooking assistant.")
            appendLine("Generate up to 3 distinct, realistic, delicious home recipes prioritizing these available ingredients: ${ingredients.joinToString(", ")}.")
            appendLine("You may assume basic pantry staples like water, salt, black pepper, and cooking oil if needed.")
            appendLine(categoryInstruction)
            appendLine("Dietary preference: ${preferences.dietaryPreference.promptHint}.")
            appendLine("User allergies to strictly avoid in suggested ingredients (and clearly flag any cross-contamination risks in allergenInfo): $allergiesText.")
            appendLine(unitInstruction)
            appendLine(spellingInstruction)
            appendLine("Provide exact numeric quantities for every ingredient (positive numbers only), clear step-by-step instructions, realistic prep/cook times, estimated nutrition per serving, allergen notes, helpful substitutions, and safe storage suggestions.")
            appendLine("Never claim a recipe is guaranteed allergen-free; remind users to check packaged labels.")
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
