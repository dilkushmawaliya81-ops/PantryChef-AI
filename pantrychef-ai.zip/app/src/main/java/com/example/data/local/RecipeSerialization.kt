package com.example.data.local

import com.example.domain.DietaryPreference
import com.example.domain.DifficultyLevel
import com.example.domain.MealCategory
import com.example.domain.MeasurementSystem
import com.example.domain.NutritionInfo
import com.example.domain.Recipe
import com.example.domain.RecipeIngredient
import com.example.domain.ShoppingCategory
import org.json.JSONArray
import org.json.JSONObject

object RecipeSerialization {

    fun toJson(recipe: Recipe): String {
        val root = JSONObject().apply {
            put("id", recipe.id)
            put("name", recipe.name)
            put("description", recipe.description)
            put("prepTimeMinutes", recipe.prepTimeMinutes)
            put("cookTimeMinutes", recipe.cookTimeMinutes)
            put("servings", recipe.servings)
            put("difficulty", recipe.difficulty.name)
            put("mealCategory", recipe.mealCategory.name)
            put("measurementSystem", recipe.measurementSystem.name)
            put("storageSuggestions", recipe.storageSuggestions)
            put("isAiGenerated", recipe.isAiGenerated)
            put("createdAt", recipe.createdAt)

            put("ingredients", JSONArray().apply {
                recipe.ingredients.forEach { ing ->
                    put(JSONObject().apply {
                        put("name", ing.name)
                        put("amount", ing.amount)
                        put("unit", ing.unit)
                        put("category", ing.category.name)
                        put("notes", ing.notes)
                    })
                }
            })

            put("steps", JSONArray(recipe.steps))
            put("allergenInfo", JSONArray(recipe.allergenInfo))
            put("substitutions", JSONArray(recipe.substitutions))
            put("dietaryTags", JSONArray(recipe.dietaryTags.map { it.name }))

            put("nutrition", JSONObject().apply {
                put("calories", recipe.nutrition.calories)
                put("proteinGrams", recipe.nutrition.proteinGrams)
                put("carbsGrams", recipe.nutrition.carbsGrams)
                put("fatGrams", recipe.nutrition.fatGrams)
                put("fiberGrams", recipe.nutrition.fiberGrams)
            })
        }
        return root.toString()
    }

    fun fromJson(
        jsonString: String,
        isFavourite: Boolean,
        isRecentGenerated: Boolean,
        lastViewedAt: Long
    ): Recipe? {
        return try {
            val obj = JSONObject(jsonString)
            val ingArray = obj.getJSONArray("ingredients")
            val ingredients = (0 until ingArray.length()).map { i ->
                val item = ingArray.getJSONObject(i)
                RecipeIngredient(
                    name = item.getString("name"),
                    amount = item.optDouble("amount", 1.0),
                    unit = item.optString("unit", ""),
                    category = runCatching {
                        ShoppingCategory.valueOf(item.optString("category", ShoppingCategory.OTHER.name))
                    }.getOrDefault(ShoppingCategory.OTHER),
                    notes = item.optString("notes", "")
                )
            }

            val stepsArray = obj.getJSONArray("steps")
            val steps = (0 until stepsArray.length()).map { stepsArray.getString(it) }

            val allergensArray = obj.optJSONArray("allergenInfo") ?: JSONArray()
            val allergens = (0 until allergensArray.length()).map { allergensArray.getString(it) }

            val subsArray = obj.optJSONArray("substitutions") ?: JSONArray()
            val subs = (0 until subsArray.length()).map { subsArray.getString(it) }

            val tagsArray = obj.optJSONArray("dietaryTags") ?: JSONArray()
            val tags = (0 until tagsArray.length()).mapNotNull { idx ->
                runCatching { DietaryPreference.valueOf(tagsArray.getString(idx)) }.getOrNull()
            }

            val nutObj = obj.optJSONObject("nutrition") ?: JSONObject()
            val nutrition = NutritionInfo(
                calories = nutObj.optInt("calories", 0),
                proteinGrams = nutObj.optInt("proteinGrams", 0),
                carbsGrams = nutObj.optInt("carbsGrams", 0),
                fatGrams = nutObj.optInt("fatGrams", 0),
                fiberGrams = nutObj.optInt("fiberGrams", 0)
            )

            Recipe(
                id = obj.getString("id"),
                name = obj.getString("name"),
                description = obj.getString("description"),
                prepTimeMinutes = obj.optInt("prepTimeMinutes", 10),
                cookTimeMinutes = obj.optInt("cookTimeMinutes", 15),
                servings = obj.optInt("servings", 2),
                ingredients = ingredients,
                steps = steps,
                difficulty = runCatching {
                    DifficultyLevel.valueOf(obj.optString("difficulty", DifficultyLevel.EASY.name))
                }.getOrDefault(DifficultyLevel.EASY),
                nutrition = nutrition,
                allergenInfo = allergens,
                substitutions = subs,
                storageSuggestions = obj.optString("storageSuggestions", ""),
                mealCategory = runCatching {
                    MealCategory.valueOf(obj.optString("mealCategory", MealCategory.DINNER.name))
                }.getOrDefault(MealCategory.DINNER),
                dietaryTags = tags,
                measurementSystem = runCatching {
                    MeasurementSystem.valueOf(obj.optString("measurementSystem", MeasurementSystem.US_CUSTOMARY.name))
                }.getOrDefault(MeasurementSystem.US_CUSTOMARY),
                isAiGenerated = obj.optBoolean("isAiGenerated", false),
                isFavourite = isFavourite,
                isRecentGenerated = isRecentGenerated,
                lastViewedAt = lastViewedAt,
                createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
        } catch (_: Exception) {
            null
        }
    }
}
