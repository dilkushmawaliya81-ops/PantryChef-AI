package com.example.domain

import java.util.UUID

enum class MeasurementSystem(val label: String) {
    US_CUSTOMARY("US Customary"),
    METRIC("Metric")
}

enum class EnglishVariant(val label: String) {
    US("English (US)"),
    UK("English (UK)")
}

enum class DietaryPreference(val displayName: String, val promptHint: String) {
    NONE("No Preference", "No specific dietary restriction"),
    VEGETARIAN("Vegetarian", "Vegetarian (no meat, poultry, or fish)"),
    VEGAN("Vegan", "Vegan (no animal products, dairy, eggs, or honey)"),
    HIGH_PROTEIN("High Protein", "High protein focused"),
    GLUTEN_FREE("Gluten-Free", "Avoids wheat, barley, rye, and gluten ingredients"),
    DAIRY_FREE("Dairy-Free", "Avoids milk, cheese, butter, cream, and yoghurt")
}

enum class MealCategory(val displayName: String) {
    BREAKFAST("Breakfast"),
    LUNCH("Lunch"),
    DINNER("Dinner"),
    SNACK("Snacks")
}

enum class DifficultyLevel(val displayName: String) {
    EASY("Easy"),
    MEDIUM("Medium"),
    HARD("Hard")
}

enum class ShoppingCategory(val displayName: String) {
    PRODUCE("Produce"),
    DAIRY("Dairy"),
    MEAT("Meat"),
    PANTRY("Pantry"),
    OTHER("Other")
}

enum class DayOfWeekSlot(val shortName: String, val fullName: String) {
    MONDAY("Mon", "Monday"),
    TUESDAY("Tue", "Tuesday"),
    WEDNESDAY("Wed", "Wednesday"),
    THURSDAY("Thu", "Thursday"),
    FRIDAY("Fri", "Friday"),
    SATURDAY("Sat", "Saturday"),
    SUNDAY("Sun", "Sunday")
}

enum class MealSlotType(val displayName: String) {
    BREAKFAST("Breakfast"),
    LUNCH("Lunch"),
    DINNER("Dinner")
}

data class RecipeIngredient(
    val name: String,
    val amount: Double,
    val unit: String,
    val category: ShoppingCategory = ShoppingCategory.OTHER,
    val notes: String = ""
)

data class NutritionInfo(
    val calories: Int,
    val proteinGrams: Int,
    val carbsGrams: Int,
    val fatGrams: Int,
    val fiberGrams: Int
)

data class Recipe(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val prepTimeMinutes: Int,
    val cookTimeMinutes: Int,
    val servings: Int,
    val ingredients: List<RecipeIngredient>,
    val steps: List<String>,
    val difficulty: DifficultyLevel,
    val nutrition: NutritionInfo,
    val allergenInfo: List<String>,
    val substitutions: List<String>,
    val storageSuggestions: String,
    val mealCategory: MealCategory = MealCategory.DINNER,
    val dietaryTags: List<DietaryPreference> = emptyList(),
    val measurementSystem: MeasurementSystem = MeasurementSystem.US_CUSTOMARY,
    val isAiGenerated: Boolean = false,
    val isFavourite: Boolean = false,
    val isRecentGenerated: Boolean = false,
    val lastViewedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalTimeMinutes: Int get() = prepTimeMinutes + cookTimeMinutes
}

data class ShoppingItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val quantityText: String,
    val category: ShoppingCategory,
    val isChecked: Boolean = false,
    val recipeSource: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class MealPlanEntry(
    val id: String = UUID.randomUUID().toString(),
    val dayOfWeek: DayOfWeekSlot,
    val mealSlot: MealSlotType,
    val recipeId: String,
    val recipeName: String,
    val mealCategory: MealCategory,
    val totalTimeMinutes: Int
)

data class UserPreferences(
    val measurementSystem: MeasurementSystem,
    val englishVariant: EnglishVariant,
    val dietaryPreference: DietaryPreference = DietaryPreference.NONE,
    val selectedAllergens: Set<String> = emptySet(),
    val customAllergies: List<String> = emptyList(),
    val dailyAiCount: Int = 0,
    val lastAiUsageDate: String = ""
) {
    val allAllergies: List<String>
        get() = (selectedAllergens + customAllergies).distinct()

    companion object {
        const val DAILY_AI_LIMIT = 5
    }
}

object CommonAllergens {
    val list = listOf(
        "Peanuts",
        "Tree Nuts",
        "Milk / Dairy",
        "Eggs",
        "Wheat / Gluten",
        "Soy",
        "Fish",
        "Shellfish",
        "Sesame"
    )
}

object ExamplePantryIngredients {
    val list = listOf(
        "eggs",
        "tomatoes",
        "chicken",
        "potatoes",
        "rice",
        "pasta",
        "milk",
        "cheese"
    )
}
