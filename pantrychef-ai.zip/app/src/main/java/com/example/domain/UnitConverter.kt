package com.example.domain

import kotlin.math.roundToInt

data class ConvertedIngredientDisplay(
    val amountText: String,
    val unitText: String,
    val fullText: String,
    val isApproximateConversion: Boolean
)

data class ConvertedStepDisplay(
    val text: String,
    val hasApproximateTemperatureConversion: Boolean
)

object UnitConverter {

    fun formatIngredient(
        ingredient: RecipeIngredient,
        sourceSystem: MeasurementSystem,
        targetSystem: MeasurementSystem,
        baseServings: Int,
        targetServings: Int,
        englishVariant: EnglishVariant = EnglishVariant.US,
        approxLabel: String = "approx."
    ): ConvertedIngredientDisplay {
        val safeBase = baseServings.coerceAtLeast(1)
        val safeTarget = targetServings.coerceAtLeast(1)
        val scaledAmount = ingredient.amount * safeTarget.toDouble() / safeBase.toDouble()

        val normalizedUnit = ingredient.unit.trim().lowercase()
        val notesSuffix = if (ingredient.notes.isNotBlank()) " (${ingredient.notes})" else ""

        if (sourceSystem == targetSystem) {
            val localizedUnit = localizeUnitSpelling(ingredient.unit, englishVariant)
            val amtText = formatNumber(scaledAmount)
            val full = buildString {
                if (amtText.isNotBlank()) append(amtText).append(" ")
                if (localizedUnit.isNotBlank()) append(localizedUnit).append(" ")
                append(ingredient.name)
                append(notesSuffix)
            }.trim()
            return ConvertedIngredientDisplay(amtText, localizedUnit, full, false)
        }

        val conversion = convertAmountAndUnit(scaledAmount, normalizedUnit, targetSystem, englishVariant)
        if (conversion != null) {
            val (convertedVal, convertedUnit) = conversion
            val amtText = formatNumber(convertedVal)
            val full = buildString {
                append(amtText).append(" ").append(convertedUnit)
                append(" ").append(ingredient.name)
                append(notesSuffix)
                append(" (").append(approxLabel).append(")")
            }.trim()
            return ConvertedIngredientDisplay(amtText, convertedUnit, full, true)
        }

        // Countable or unitless items (e.g., "large", "cloves", "eggs", "pinch") do not need unit conversion
        val amtText = formatNumber(scaledAmount)
        val localizedUnit = localizeUnitSpelling(ingredient.unit, englishVariant)
        val full = buildString {
            if (amtText.isNotBlank()) append(amtText).append(" ")
            if (localizedUnit.isNotBlank()) append(localizedUnit).append(" ")
            append(ingredient.name)
            append(notesSuffix)
        }.trim()
        return ConvertedIngredientDisplay(amtText, localizedUnit, full, false)
    }

    private fun convertAmountAndUnit(
        amount: Double,
        unit: String,
        targetSystem: MeasurementSystem,
        englishVariant: EnglishVariant
    ): Pair<Double, String>? {
        return when (targetSystem) {
            MeasurementSystem.METRIC -> when (unit) {
                "cup", "cups" -> {
                    val ml = amount * 236.588
                    if (ml >= 1000.0) (ml / 1000.0) to litresUnit(englishVariant) else roundToSensible(ml) to "ml"
                }
                "tbsp", "tablespoon", "tablespoons" -> roundToSensible(amount * 14.787) to "ml"
                "tsp", "teaspoon", "teaspoons" -> roundToSensible(amount * 4.929) to "ml"
                "fl oz", "fluid ounce", "fluid ounces" -> roundToSensible(amount * 29.574) to "ml"
                "oz", "ounce", "ounces" -> {
                    val grams = amount * 28.3495
                    if (grams >= 1000.0) (grams / 1000.0) to "kg" else roundToSensible(grams) to "g"
                }
                "lb", "lbs", "pound", "pounds" -> {
                    val grams = amount * 453.592
                    if (grams >= 1000.0) ((grams / 1000.0 * 100.0).roundToInt() / 100.0) to "kg" else roundToSensible(grams) to "g"
                }
                else -> null
            }

            MeasurementSystem.US_CUSTOMARY -> when (unit) {
                "ml", "milliliter", "milliliters", "millilitre", "millilitres" -> {
                    when {
                        amount >= 200.0 -> (amount / 236.588) to if (amount / 236.588 > 1.05) "cups" else "cup"
                        amount >= 14.0 -> (amount / 14.787) to "tbsp"
                        else -> (amount / 4.929) to "tsp"
                    }
                }
                "l", "liter", "liters", "litre", "litres" -> {
                    val cups = (amount * 1000.0) / 236.588
                    cups to if (cups > 1.05) "cups" else "cup"
                }
                "g", "gram", "grams" -> {
                    if (amount >= 450.0) (amount / 453.592) to "lb" else (amount / 28.3495) to "oz"
                }
                "kg", "kilogram", "kilograms" -> {
                    (amount * 2.20462) to "lb"
                }
                else -> null
            }
        }
    }

    private fun litresUnit(variant: EnglishVariant): String =
        if (variant == EnglishVariant.UK) "l" else "L"

    private fun localizeUnitSpelling(unit: String, variant: EnglishVariant): String {
        return when (unit.trim().lowercase()) {
            "milliliters", "millilitres" -> if (variant == EnglishVariant.UK) "millilitres" else "milliliters"
            "milliliter", "millilitre" -> if (variant == EnglishVariant.UK) "millilitre" else "milliliter"
            "liters", "litres" -> if (variant == EnglishVariant.UK) "litres" else "liters"
            "liter", "litre" -> if (variant == EnglishVariant.UK) "litre" else "liter"
            else -> unit
        }
    }

    private fun roundToSensible(value: Double): Double {
        return when {
            value >= 100 -> (value / 5.0).roundToInt() * 5.0
            value >= 20 -> value.roundToInt().toDouble()
            else -> (value * 10.0).roundToInt() / 10.0
        }
    }

    fun formatNumber(value: Double): String {
        if (value <= 0.0) return ""
        val rounded = (value * 100.0).roundToInt() / 100.0
        val whole = rounded.toInt()
        val frac = rounded - whole

        val fracStr = when {
            frac < 0.06 -> ""
            frac in 0.20..0.30 -> "1/4"
            frac in 0.30..0.38 -> "1/3"
            frac in 0.45..0.55 -> "1/2"
            frac in 0.62..0.71 -> "2/3"
            frac in 0.71..0.80 -> "3/4"
            frac > 0.94 -> return (whole + 1).toString()
            else -> {
                val oneDecimal = ((value * 10.0).roundToInt() / 10.0)
                return if (oneDecimal % 1.0 == 0.0) oneDecimal.toInt().toString() else oneDecimal.toString()
            }
        }

        return when {
            whole == 0 && fracStr.isNotEmpty() -> fracStr
            whole > 0 && fracStr.isNotEmpty() -> "$whole $fracStr"
            else -> whole.toString()
        }
    }

    private val fahrenheitRegex = Regex("""(\d{2,3})\s*°\s*F\b""", RegexOption.IGNORE_CASE)
    private val celsiusRegex = Regex("""(\d{2,3})\s*°\s*C\b""", RegexOption.IGNORE_CASE)

    fun convertStepTemperatures(
        stepText: String,
        targetSystem: MeasurementSystem,
        approxLabel: String = "approx."
    ): ConvertedStepDisplay {
        var converted = false
        val updated = when (targetSystem) {
            MeasurementSystem.METRIC -> {
                fahrenheitRegex.replace(stepText) { match ->
                    converted = true
                    val f = match.groupValues[1].toIntOrNull() ?: return@replace match.value
                    val c = (((f - 32) * 5.0 / 9.0) / 5.0).roundToInt() * 5
                    "$c°C ($approxLabel)"
                }
            }
            MeasurementSystem.US_CUSTOMARY -> {
                celsiusRegex.replace(stepText) { match ->
                    converted = true
                    val c = match.groupValues[1].toIntOrNull() ?: return@replace match.value
                    val f = (((c * 9.0 / 5.0) + 32) / 5.0).roundToInt() * 5
                    "$f°F ($approxLabel)"
                }
            }
        }
        return ConvertedStepDisplay(updated, converted)
    }
}
