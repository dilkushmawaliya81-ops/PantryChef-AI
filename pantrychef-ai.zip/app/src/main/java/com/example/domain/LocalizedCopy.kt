package com.example.domain

data class LocalizedStrings(
    val navFavourites: String,
    val favouritesTitle: String,
    val favouritesEmptyTitle: String,
    val favouritesEmptyHint: String,
    val addToFavourites: String,
    val removeFromFavourites: String,
    val customisePreferences: String,
    val organiseShoppingList: String,
    val measurementUsDescription: String,
    val measurementMetricDescription: String,
    val flavourNote: String,
    val fibreLabel: String,
    val approxUnitLabel: String
)

object LocalizedCopy {
    fun forVariant(variant: EnglishVariant): LocalizedStrings = when (variant) {
        EnglishVariant.US -> LocalizedStrings(
            navFavourites = "Favorites",
            favouritesTitle = "Favorites & History",
            favouritesEmptyTitle = "No favorite recipes yet",
            favouritesEmptyHint = "Tap the heart on any recipe to save it locally for offline cooking.",
            addToFavourites = "Add to Favorites",
            removeFromFavourites = "Saved in Favorites",
            customisePreferences = "Customize Dietary & Units",
            organiseShoppingList = "Organized by grocery aisle",
            measurementUsDescription = "Cups, tablespoons, teaspoons, ounces, pounds, °F",
            measurementMetricDescription = "Grams, kilograms, milliliters, liters, °C",
            flavourNote = "Flavor & Substitutions",
            fibreLabel = "Fiber",
            approxUnitLabel = "approx."
        )
        EnglishVariant.UK -> LocalizedStrings(
            navFavourites = "Favourites",
            favouritesTitle = "Favourites & History",
            favouritesEmptyTitle = "No favourite recipes yet",
            favouritesEmptyHint = "Tap the heart on any recipe to save it locally for offline cooking.",
            addToFavourites = "Add to Favourites",
            removeFromFavourites = "Saved in Favourites",
            customisePreferences = "Customise Dietary & Units",
            organiseShoppingList = "Organised by grocery aisle",
            measurementUsDescription = "Cups, tablespoons, teaspoons, ounces, pounds, °F",
            measurementMetricDescription = "Grams, kilograms, millilitres, litres, °C",
            flavourNote = "Flavour & Substitutions",
            fibreLabel = "Fibre",
            approxUnitLabel = "approx."
        )
    }
}
