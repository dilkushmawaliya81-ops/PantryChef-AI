package com.example.domain

object SampleRecipes {

    val all: List<Recipe> = listOf(
        Recipe(
            id = "sample_tomato_egg_skillet",
            name = "Mediterranean Tomato & Egg Skillet",
            description = "A comforting one-pan skillet of gently poached eggs in spiced ripe tomatoes, garlic, and melted cheese.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 15,
            servings = 2,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.BREAKFAST,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE, DietaryPreference.HIGH_PROTEIN),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("eggs", 4.0, "large", ShoppingCategory.DAIRY),
                RecipeIngredient("ripe tomatoes, diced", 2.0, "cups", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 1.0, "tbsp", ShoppingCategory.PANTRY),
                RecipeIngredient("garlic cloves, minced", 2.0, "cloves", ShoppingCategory.PRODUCE),
                RecipeIngredient("crumbled feta or cheddar cheese", 2.0, "oz", ShoppingCategory.DAIRY),
                RecipeIngredient("smoked paprika", 0.5, "tsp", ShoppingCategory.PANTRY),
                RecipeIngredient("salt and black pepper", 0.5, "tsp", ShoppingCategory.PANTRY, "to taste")
            ),
            steps = listOf(
                "Warm the olive oil in a medium frying pan over medium heat (about 350°F).",
                "Add the minced garlic and cook for 30 seconds until fragrant without browning.",
                "Stir in the diced tomatoes, smoked paprika, salt, and pepper. Simmer for 6 to 8 minutes until thickened.",
                "Make 4 small wells in the tomato sauce and crack an egg into each well.",
                "Cover with a lid and cook gently for 4 to 6 minutes until egg whites are set and yolks remain soft.",
                "Scatter the cheese over the top, let melt for 1 minute, and serve warm."
            ),
            nutrition = NutritionInfo(calories = 310, proteinGrams = 19, carbsGrams = 11, fatGrams = 21, fiberGrams = 3),
            allergenInfo = listOf("Eggs", "Milk / Dairy"),
            substitutions = listOf(
                "Swap fresh tomatoes for 1 can (14 oz) diced tomatoes.",
                "Use dairy-free feta alternative or omit cheese for Dairy-Free."
            ),
            storageSuggestions = "Best eaten fresh. Store leftover tomato base in an airtight container in the fridge for up to 3 days and reheat with freshly cooked eggs."
        ),
        Recipe(
            id = "sample_garlic_chicken_rice",
            name = "Lemon Herb Chicken & Rice Bowl",
            description = "Tender pan-seared chicken breast served over fluffy rice with roasted cherry tomatoes and fresh herbs.",
            prepTimeMinutes = 15,
            cookTimeMinutes = 25,
            servings = 4,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.DINNER,
            dietaryTags = listOf(DietaryPreference.HIGH_PROTEIN, DietaryPreference.GLUTEN_FREE, DietaryPreference.DAIRY_FREE),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("chicken breast, cubed", 1.25, "lb", ShoppingCategory.MEAT),
                RecipeIngredient("long-grain white or jasmine rice", 1.5, "cups", ShoppingCategory.PANTRY),
                RecipeIngredient("water or chicken broth", 3.0, "cups", ShoppingCategory.PANTRY),
                RecipeIngredient("cherry tomatoes, halved", 1.5, "cups", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 2.0, "tbsp", ShoppingCategory.PANTRY),
                RecipeIngredient("dried oregano", 1.0, "tsp", ShoppingCategory.PANTRY),
                RecipeIngredient("lemon juice", 2.0, "tbsp", ShoppingCategory.PRODUCE)
            ),
            steps = listOf(
                "Rinse the rice under cold water, then bring to a boil with the water or broth in a lidded saucepan. Reduce to low and simmer covered for 15 minutes.",
                "Season the cubed chicken with oregano, salt, pepper, and 1 tbsp olive oil.",
                "Heat the remaining olive oil in a large skillet over medium-high heat and sear the chicken for 6 to 7 minutes until golden and cooked through (165°F internal).",
                "Toss in the cherry tomatoes and lemon juice for the final 2 minutes until tomatoes soften slightly.",
                "Fluff the cooked rice with a fork and serve topped with the chicken and pan juices."
            ),
            nutrition = NutritionInfo(calories = 460, proteinGrams = 36, carbsGrams = 52, fatGrams = 11, fiberGrams = 2),
            allergenInfo = listOf("Check stock/broth labels for hidden gluten, soy, or celery."),
            substitutions = listOf(
                "Substitute chicken thighs for extra juiciness.",
                "Swap white rice for brown rice (increase simmering time to 35–40 minutes)."
            ),
            storageSuggestions = "Refrigerate in sealed containers for up to 4 days. Reheat thoroughly with a splash of water until piping hot."
        ),
        Recipe(
            id = "sample_creamy_tomato_pasta",
            name = "20-Minute Creamy Tomato Pasta",
            description = "Silky tomato-garlic pasta finished with a splash of milk and grated cheese for a cosy weeknight meal.",
            prepTimeMinutes = 5,
            cookTimeMinutes = 15,
            servings = 3,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.DINNER,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("dried pasta (penne or spaghetti)", 10.0, "oz", ShoppingCategory.PANTRY),
                RecipeIngredient("fresh tomatoes, chopped", 2.5, "cups", ShoppingCategory.PRODUCE),
                RecipeIngredient("milk", 0.5, "cup", ShoppingCategory.DAIRY),
                RecipeIngredient("grated cheddar or parmesan cheese", 0.75, "cup", ShoppingCategory.DAIRY),
                RecipeIngredient("olive oil or butter", 1.5, "tbsp", ShoppingCategory.PANTRY),
                RecipeIngredient("garlic cloves, finely chopped", 2.0, "cloves", ShoppingCategory.PRODUCE)
            ),
            steps = listOf(
                "Boil the pasta in salted water according to package directions until al dente; reserve 1/2 cup cooking water before draining.",
                "Meanwhile, heat oil in a wide pan over medium heat, add garlic for 30 seconds, then add chopped tomatoes and a pinch of salt.",
                "Simmer tomatoes for 8 minutes, pressing gently with a spoon to form a chunky sauce.",
                "Lower heat, stir in the milk and grated cheese until smooth, adding splashes of reserved pasta water if needed.",
                "Toss the drained pasta into the sauce and serve immediately."
            ),
            nutrition = NutritionInfo(calories = 485, proteinGrams = 19, carbsGrams = 67, fatGrams = 15, fiberGrams = 4),
            allergenInfo = listOf("Wheat / Gluten", "Milk / Dairy"),
            substitutions = listOf(
                "Use gluten-free pasta to make this dish Gluten-Free.",
                "Replace milk and cheese with unsweetened oat milk and nutritional yeast for Vegan."
            ),
            storageSuggestions = "Keeps in the fridge for up to 3 days. Add 1–2 tbsp water or milk when reheating on the stove."
        ),
        Recipe(
            id = "sample_crispy_potato_egg_hash",
            name = "Crispy Herb Potato & Egg Hash",
            description = "Golden pan-fried diced potatoes with sweet tomatoes and fried eggs for a hearty breakfast or lunch.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 20,
            servings = 2,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.LUNCH,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE, DietaryPreference.DAIRY_FREE),
            measurementSystem = MeasurementSystem.METRIC,
            ingredients = listOf(
                RecipeIngredient("potatoes, scrubbed and diced small", 400.0, "g", ShoppingCategory.PRODUCE),
                RecipeIngredient("eggs", 3.0, "large", ShoppingCategory.DAIRY),
                RecipeIngredient("tomatoes, diced", 150.0, "g", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 20.0, "ml", ShoppingCategory.PANTRY),
                RecipeIngredient("dried thyme or rosemary", 1.0, "tsp", ShoppingCategory.PANTRY),
                RecipeIngredient("salt and black pepper", 0.5, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Pat the diced potatoes dry with a clean tea towel or kitchen paper.",
                "Heat oil in a non-stick frying pan over medium heat (around 180°C) and add potatoes with thyme, salt, and pepper.",
                "Cook for 14 to 16 minutes, stirring occasionally so all sides turn crisp and golden.",
                "Stir in diced tomatoes for 2 minutes, then push hash aside and fry the eggs right in the pan until cooked to your liking."
            ),
            nutrition = NutritionInfo(calories = 390, proteinGrams = 15, carbsGrams = 42, fatGrams = 18, fiberGrams = 5),
            allergenInfo = listOf("Eggs"),
            substitutions = listOf(
                "Add diced bell pepper or onion if available.",
                "Swap eggs for seasoned chickpeas for a Vegan hash."
            ),
            storageSuggestions = "Potato hash base keeps refrigerated for 3 days; re-crisp in a dry frying pan before serving with fresh eggs."
        ),
        Recipe(
            id = "sample_chickpea_tomato_rice",
            name = "Spiced Tomato & Chickpea Rice Pot",
            description = "A fragrant one-pot plant-based meal simmered with warming cumin, tomatoes, and fluffy rice.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 22,
            servings = 4,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.DINNER,
            dietaryTags = listOf(DietaryPreference.VEGAN, DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE, DietaryPreference.DAIRY_FREE),
            measurementSystem = MeasurementSystem.METRIC,
            ingredients = listOf(
                RecipeIngredient("basmati or long-grain rice", 250.0, "g", ShoppingCategory.PANTRY),
                RecipeIngredient("canned chickpeas, drained", 400.0, "g", ShoppingCategory.PANTRY),
                RecipeIngredient("ripe tomatoes, finely chopped", 300.0, "g", ShoppingCategory.PRODUCE),
                RecipeIngredient("vegetable stock or water", 500.0, "ml", ShoppingCategory.PANTRY),
                RecipeIngredient("olive oil", 15.0, "ml", ShoppingCategory.PANTRY),
                RecipeIngredient("ground cumin", 1.0, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Heat olive oil in a heavy saucepan over medium heat and toast the cumin for 30 seconds.",
                "Add chopped tomatoes and cook for 4 minutes until juicy.",
                "Stir in rinsed rice, drained chickpeas, and vegetable stock. Bring to a simmer.",
                "Cover tightly, turn heat to low, and cook for 15 minutes without lifting the lid.",
                "Rest off the heat for 5 minutes, then fluff with a fork and serve."
            ),
            nutrition = NutritionInfo(calories = 410, proteinGrams = 13, carbsGrams = 72, fatGrams = 7, fiberGrams = 8),
            allergenInfo = listOf("Check vegetable stock label for celery or soy."),
            substitutions = listOf(
                "Use red lentils or black beans instead of chickpeas.",
                "Stir in a handful of baby spinach at the end for extra greens."
            ),
            storageSuggestions = "Stores well in the refrigerator for 4 days or freezes for up to 2 months."
        ),
        Recipe(
            id = "sample_cheesy_baked_potato",
            name = "Loaded Cheesy Herb Jacket Potato",
            description = "Fluffy oven-baked potatoes topped with melted cheese, warm diced tomatoes, and black pepper.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 50,
            servings = 2,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.LUNCH,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE),
            measurementSystem = MeasurementSystem.METRIC,
            ingredients = listOf(
                RecipeIngredient("large baking potatoes", 2.0, "whole", ShoppingCategory.PRODUCE),
                RecipeIngredient("grated mature cheddar cheese", 80.0, "g", ShoppingCategory.DAIRY),
                RecipeIngredient("milk or plain yoghurt", 30.0, "ml", ShoppingCategory.DAIRY),
                RecipeIngredient("tomatoes, finely diced", 120.0, "g", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 10.0, "ml", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Preheat the oven to 200°C. Prick the potatoes several times with a fork, rub with olive oil and a pinch of salt.",
                "Bake directly on the oven rack for 45 to 50 minutes until crisp outside and tender inside.",
                "Split the potatoes open, fluff the insides with a fork, and stir in the milk or yoghurt.",
                "Top generously with grated cheese and diced tomatoes, then return to the oven for 3 minutes until bubbling."
            ),
            nutrition = NutritionInfo(calories = 420, proteinGrams = 16, carbsGrams = 54, fatGrams = 16, fiberGrams = 6),
            allergenInfo = listOf("Milk / Dairy"),
            substitutions = listOf(
                "Microwave potatoes for 8–10 minutes first and finish in a 200°C oven for 12 minutes to save time.",
                "Use plant-based cheese and oat milk for Vegan."
            ),
            storageSuggestions = "Refrigerate leftover baked potatoes up to 3 days and reheat in the oven or air fryer."
        ),
        Recipe(
            id = "sample_protein_egg_muffins",
            name = "Cheesy Tomato Egg Bake Cups",
            description = "Grab-and-go savoury egg muffins packed with protein, diced tomatoes, and melted cheddar.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 18,
            servings = 4,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.SNACK,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN, DietaryPreference.HIGH_PROTEIN, DietaryPreference.GLUTEN_FREE),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("eggs", 6.0, "large", ShoppingCategory.DAIRY),
                RecipeIngredient("milk", 0.25, "cup", ShoppingCategory.DAIRY),
                RecipeIngredient("diced tomatoes, seeded", 0.75, "cup", ShoppingCategory.PRODUCE),
                RecipeIngredient("shredded cheddar cheese", 0.5, "cup", ShoppingCategory.DAIRY),
                RecipeIngredient("salt and pepper", 0.5, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Preheat oven to 350°F and lightly grease 6 cups of a standard muffin tin.",
                "Whisk together eggs, milk, salt, and pepper until smooth.",
                "Divide diced tomatoes and shredded cheese evenly among the muffin cups.",
                "Pour egg mixture into each cup until three-quarters full.",
                "Bake for 16 to 18 minutes until puffed and set in the center. Cool 5 minutes before removing."
            ),
            nutrition = NutritionInfo(calories = 180, proteinGrams = 14, carbsGrams = 3, fatGrams = 12, fiberGrams = 1),
            allergenInfo = listOf("Eggs", "Milk / Dairy"),
            substitutions = listOf(
                "Swap milk for unsweetened almond milk or omit cheese if reducing dairy."
            ),
            storageSuggestions = "Keep refrigerated for up to 4 days; reheat in 20–30 second bursts."
        ),
        Recipe(
            id = "sample_crispy_potato_bites",
            name = "Herb-Roasted Crispy Potato Bites",
            description = "Oven-roasted bite-sized potato cubes seasoned with garlic and herbs for an effortless snack or side.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 25,
            servings = 3,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.SNACK,
            dietaryTags = listOf(DietaryPreference.VEGAN, DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE, DietaryPreference.DAIRY_FREE),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("potatoes, cut into 3/4-inch cubes", 1.0, "lb", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 1.5, "tbsp", ShoppingCategory.PANTRY),
                RecipeIngredient("garlic powder", 0.5, "tsp", ShoppingCategory.PANTRY),
                RecipeIngredient("dried Italian herbs", 1.0, "tsp", ShoppingCategory.PANTRY),
                RecipeIngredient("sea salt", 0.5, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Preheat oven to 425°F and line a baking sheet with parchment paper.",
                "Toss cubed potatoes with olive oil, garlic powder, Italian herbs, and salt.",
                "Spread in a single layer with space between pieces.",
                "Roast for 22 to 25 minutes, tossing halfway through, until deeply golden and crisp."
            ),
            nutrition = NutritionInfo(calories = 195, proteinGrams = 3, carbsGrams = 29, fatGrams = 7, fiberGrams = 3),
            allergenInfo = listOf("No major common allergens in base recipe; verify spice blend labels."),
            substitutions = listOf(
                "Use sweet potatoes instead of white potatoes for extra sweetness."
            ),
            storageSuggestions = "Store cooled bites in the fridge up to 3 days and re-crisp in a hot oven or air fryer."
        ),
        Recipe(
            id = "sample_high_protein_chicken_pasta",
            name = "Garlic Chicken & Tomato Pasta Skillet",
            description = "High-protein seared chicken tossed with whole-wheat or classic pasta and a bright tomato glaze.",
            prepTimeMinutes = 10,
            cookTimeMinutes = 20,
            servings = 3,
            difficulty = DifficultyLevel.MEDIUM,
            mealCategory = MealCategory.LUNCH,
            dietaryTags = listOf(DietaryPreference.HIGH_PROTEIN, DietaryPreference.DAIRY_FREE),
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            ingredients = listOf(
                RecipeIngredient("chicken breast, sliced into strips", 1.0, "lb", ShoppingCategory.MEAT),
                RecipeIngredient("pasta", 8.0, "oz", ShoppingCategory.PANTRY),
                RecipeIngredient("ripe tomatoes, diced", 2.0, "cups", ShoppingCategory.PRODUCE),
                RecipeIngredient("olive oil", 1.5, "tbsp", ShoppingCategory.PANTRY),
                RecipeIngredient("garlic cloves, sliced", 2.0, "cloves", ShoppingCategory.PRODUCE),
                RecipeIngredient("dried basil", 1.0, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Cook pasta in salted boiling water until al dente, saving 1/3 cup pasta water.",
                "Sear seasoned chicken strips in olive oil over medium-high heat for 5 to 6 minutes until cooked through (165°F).",
                "Add sliced garlic, diced tomatoes, and basil; simmer 4 minutes until juicy.",
                "Toss cooked pasta and a splash of pasta water into the skillet to coat evenly and serve hot."
            ),
            nutrition = NutritionInfo(calories = 490, proteinGrams = 41, carbsGrams = 56, fatGrams = 10, fiberGrams = 4),
            allergenInfo = listOf("Wheat / Gluten"),
            substitutions = listOf(
                "Use chickpea or lentil pasta for Gluten-Free and extra protein."
            ),
            storageSuggestions = "Refrigerate up to 3 days in a sealed container."
        ),
        Recipe(
            id = "sample_vanilla_rice_porridge",
            name = "Warm Cinnamon Milk Rice Pudding",
            description = "Creamy stovetop rice breakfast gently simmered in milk with a touch of cinnamon and honey or sugar.",
            prepTimeMinutes = 5,
            cookTimeMinutes = 20,
            servings = 2,
            difficulty = DifficultyLevel.EASY,
            mealCategory = MealCategory.BREAKFAST,
            dietaryTags = listOf(DietaryPreference.VEGETARIAN, DietaryPreference.GLUTEN_FREE),
            measurementSystem = MeasurementSystem.METRIC,
            ingredients = listOf(
                RecipeIngredient("cooked or short-grain white rice", 150.0, "g", ShoppingCategory.PANTRY),
                RecipeIngredient("milk", 400.0, "ml", ShoppingCategory.DAIRY),
                RecipeIngredient("sugar or maple syrup", 15.0, "g", ShoppingCategory.PANTRY),
                RecipeIngredient("ground cinnamon", 0.5, "tsp", ShoppingCategory.PANTRY)
            ),
            steps = listOf(
                "Combine rice, milk, and cinnamon in a small saucepan over medium-low heat.",
                "Simmer gently for 15 to 18 minutes, stirring often so the bottom does not stick, until thick and creamy.",
                "Stir in sugar or maple syrup to taste and serve warm."
            ),
            nutrition = NutritionInfo(calories = 285, proteinGrams = 10, carbsGrams = 48, fatGrams = 6, fiberGrams = 1),
            allergenInfo = listOf("Milk / Dairy"),
            substitutions = listOf(
                "Use fortified soy or oat milk for Dairy-Free and Vegan."
            ),
            storageSuggestions = "Keep chilled up to 3 days; loosen with a splash of milk when reheating."
        )
    )
}
