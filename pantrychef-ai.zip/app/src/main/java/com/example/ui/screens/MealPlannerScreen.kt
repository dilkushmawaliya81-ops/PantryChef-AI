package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.DayOfWeekSlot
import com.example.domain.MealPlanEntry
import com.example.domain.MealSlotType
import com.example.domain.Recipe
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealPlannerScreen(
    mealPlans: List<MealPlanEntry>,
    availableRecipes: List<Recipe>,
    onAssignMeal: (DayOfWeekSlot, MealSlotType, Recipe) -> Unit,
    onRemoveMeal: (DayOfWeekSlot, MealSlotType) -> Unit,
    onOpenRecipeById: (String) -> Unit,
    onAddDayToShoppingList: (DayOfWeekSlot) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDay by rememberSaveable { mutableStateOf(DayOfWeekSlot.MONDAY) }
    var pickingSlot by remember { mutableStateOf<MealSlotType?>(null) }

    val dayPlans = remember(mealPlans, selectedDay) {
        mealPlans.filter { it.dayOfWeek == selectedDay }.associateBy { it.mealSlot }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("planner_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Weekly Meal Planner",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Plan Breakfast, Lunch, and Dinner across your week. Stored locally offline.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Day Selector
        item {
            LazyRow(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(DayOfWeekSlot.entries) { day ->
                    val dayCount = mealPlans.count { it.dayOfWeek == day }
                    val isSelected = day == selectedDay
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedDay = day },
                        label = {
                            Text(if (dayCount > 0) "${day.shortName} ($dayCount)" else day.shortName)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = CharcoalSurfaceElevated,
                            labelColor = TextSecondary,
                            selectedContainerColor = FreshGreenContainer,
                            selectedLabelColor = OnFreshGreenContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = CharcoalOutline,
                            selectedBorderColor = FreshGreen
                        ),
                        modifier = Modifier.testTag("planner_day_${day.name}")
                    )
                }
            }
        }

        if (mealPlans.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Outlined.CalendarMonth,
                    title = "No meals planned yet",
                    subtitle = "Tap + on Breakfast, Lunch, or Dinner below to schedule recipes for ${selectedDay.fullName}.",
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .testTag("planner_empty_state")
                )
            }
        }

        item {
            Row(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedDay.fullName,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                if (dayPlans.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { onAddDayToShoppingList(selectedDay) },
                        border = BorderStroke(1.dp, FreshGreen.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingCart,
                            contentDescription = null,
                            tint = FreshGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Shop Day", color = FreshGreen)
                    }
                }
            }
        }

        items(MealSlotType.entries) { slot ->
            val planned = dayPlans[slot]
            Card(
                modifier = Modifier
                    .widthIn(max = 800.dp)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                border = BorderStroke(1.dp, CharcoalOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = slot.displayName,
                            style = MaterialTheme.typography.labelLarge,
                            color = WarmOrange
                        )
                        if (planned == null) {
                            TextButton(
                                onClick = { pickingSlot = slot },
                                modifier = Modifier.testTag("planner_add_${slot.name}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Add ${slot.displayName}",
                                    tint = FreshGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Recipe", color = FreshGreen)
                            }
                        } else {
                            Row {
                                IconButton(
                                    onClick = { pickingSlot = slot },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.SwapHoriz,
                                        contentDescription = "Replace ${slot.displayName}",
                                        tint = TextSecondary
                                    )
                                }
                                IconButton(
                                    onClick = { onRemoveMeal(selectedDay, slot) },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("planner_remove_${slot.name}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = "Remove ${slot.displayName}",
                                        tint = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    if (planned == null) {
                        Text(
                            text = "Nothing planned for ${slot.displayName.lowercase()}.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    } else {
                        Surface(
                            color = CharcoalSurface,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenRecipeById(planned.recipeId) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = planned.recipeName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${planned.mealCategory.displayName} • ${planned.totalTimeMinutes} min total • Tap to open",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = FreshGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
    }

    val activeSlot = pickingSlot
    if (activeSlot != null) {
        ModalBottomSheet(
            onDismissRequest = { pickingSlot = null },
            containerColor = CharcoalSurfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Choose ${activeSlot.displayName} for ${selectedDay.fullName}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(360.dp)
                ) {
                    items(availableRecipes, key = { it.id }) { recipe ->
                        Surface(
                            color = CharcoalSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CharcoalOutline),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onAssignMeal(selectedDay, activeSlot, recipe)
                                    pickingSlot = null
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = recipe.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${recipe.mealCategory.displayName} • ${recipe.totalTimeMinutes} min",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Select ${recipe.name}",
                                    tint = FreshGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
