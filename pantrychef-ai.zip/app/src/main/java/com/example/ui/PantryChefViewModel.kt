package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRecipeResult
import com.example.data.ai.FirebaseAiRecipeService
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesDataStore
import com.example.data.repository.PantryChefRepository
import com.example.domain.DayOfWeekSlot
import com.example.domain.DietaryPreference
import com.example.domain.EnglishVariant
import com.example.domain.LocalizedCopy
import com.example.domain.MealCategory
import com.example.domain.MealPlanEntry
import com.example.domain.MealSlotType
import com.example.domain.MeasurementSystem
import com.example.domain.Recipe
import com.example.domain.RecipeIngredient
import com.example.domain.SampleRecipes
import com.example.domain.ShoppingCategory
import com.example.domain.ShoppingItem
import com.example.domain.UnitConverter
import com.example.domain.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

sealed interface AiGenerationUiState {
    data object Idle : AiGenerationUiState
    data object Loading : AiGenerationUiState
    data class Success(
        val recipes: List<Recipe>,
        val usedIngredients: List<String>
    ) : AiGenerationUiState
    data class Error(
        val message: String,
        val isQuotaOrOffline: Boolean
    ) : AiGenerationUiState
}

class PantryChefViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val preferencesDataStore = PreferencesDataStore(application)
    private val aiService = FirebaseAiRecipeService(application)
    private val repository = PantryChefRepository(
        recipeDao = database.recipeDao(),
        mealPlanDao = database.mealPlanDao(),
        shoppingListDao = database.shoppingListDao(),
        preferencesDataStore = preferencesDataStore,
        aiRecipeService = aiService
    )

    val preferences: StateFlow<UserPreferences> = repository.preferencesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = UserPreferences(
            measurementSystem = if (Locale.getDefault().country.equals("US", ignoreCase = true)) {
                MeasurementSystem.US_CUSTOMARY
            } else MeasurementSystem.METRIC,
            englishVariant = if (Locale.getDefault().country.equals("GB", ignoreCase = true)) {
                EnglishVariant.UK
            } else EnglishVariant.US
        )
    )

    val favourites: StateFlow<List<Recipe>> = repository.favouritesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val recentGenerated: StateFlow<List<Recipe>> = repository.recentGeneratedFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val recentlyViewed: StateFlow<List<Recipe>> = repository.recentlyViewedFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val mealPlans: StateFlow<List<MealPlanEntry>> = repository.mealPlanFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val shoppingItems: StateFlow<List<ShoppingItem>> = repository.shoppingListFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val sampleRecipes: List<Recipe> = SampleRecipes.all

    private val _pantryIngredients = MutableStateFlow<List<String>>(emptyList())
    val pantryIngredients: StateFlow<List<String>> = _pantryIngredients.asStateFlow()

    private val _selectedMealCategory = MutableStateFlow<MealCategory?>(null)
    val selectedMealCategory: StateFlow<MealCategory?> = _selectedMealCategory.asStateFlow()

    private val _aiState = MutableStateFlow<AiGenerationUiState>(AiGenerationUiState.Idle)
    val aiState: StateFlow<AiGenerationUiState> = _aiState.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    fun addIngredient(rawInput: String) {
        val parts = rawInput.split(",")
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotBlank() }
        if (parts.isEmpty()) return
        val current = _pantryIngredients.value.toMutableList()
        parts.forEach { item ->
            if (current.none { it.equals(item, ignoreCase = true) }) {
                current.add(item)
            }
        }
        _pantryIngredients.value = current
    }

    fun removeIngredient(ingredient: String) {
        _pantryIngredients.value = _pantryIngredients.value.filterNot {
            it.equals(ingredient, ignoreCase = true)
        }
    }

    fun toggleIngredient(ingredient: String) {
        if (_pantryIngredients.value.any { it.equals(ingredient, ignoreCase = true) }) {
            removeIngredient(ingredient)
        } else {
            addIngredient(ingredient)
        }
    }

    fun clearIngredients() {
        _pantryIngredients.value = emptyList()
    }

    fun selectMealCategory(category: MealCategory?) {
        _selectedMealCategory.value = if (_selectedMealCategory.value == category) null else category
    }

    fun generateRecipes() {
        val ingredients = _pantryIngredients.value
        if (ingredients.isEmpty()) {
            emitSnackbar("Add at least one ingredient from your kitchen first.")
            return
        }
        runAiGeneration(ingredients, _selectedMealCategory.value)
    }

    fun generateAnotherFromRecipe(recipe: Recipe) {
        val baseIngredients = recipe.ingredients.take(4).map { it.name.substringBefore(",").trim() }
        val activeIngredients = _pantryIngredients.value.ifEmpty { baseIngredients }
        if (activeIngredients.isNotEmpty()) {
            _pantryIngredients.value = activeIngredients
        }
        runAiGeneration(activeIngredients, recipe.mealCategory)
    }

    private fun runAiGeneration(ingredients: List<String>, category: MealCategory?) {
        viewModelScope.launch {
            _aiState.value = AiGenerationUiState.Loading
            when (val result = repository.generateRecipes(ingredients, category)) {
                is AiRecipeResult.Success -> {
                    _aiState.value = AiGenerationUiState.Success(
                        recipes = result.recipes,
                        usedIngredients = ingredients
                    )
                }
                is AiRecipeResult.Error -> {
                    _aiState.value = AiGenerationUiState.Error(
                        message = result.message,
                        isQuotaOrOffline = result.isQuotaOrOffline
                    )
                }
            }
        }
    }

    fun dismissAiResult() {
        _aiState.value = AiGenerationUiState.Idle
    }

    fun observeRecipe(recipeId: String): Flow<Recipe?> = repository.observeRecipeById(recipeId)

    fun markRecipeViewed(recipe: Recipe) {
        viewModelScope.launch {
            repository.markRecipeViewed(recipe)
        }
    }

    fun toggleFavourite(recipe: Recipe) {
        viewModelScope.launch {
            val wasFav = recipe.isFavourite
            repository.toggleFavourite(recipe)
            val prefs = preferences.value
            val label = if (prefs.englishVariant == EnglishVariant.UK) "Favourites" else "Favorites"
            emitSnackbar(if (wasFav) "Removed from $label" else "Saved to $label")
        }
    }

    fun addIngredientsToShoppingList(
        recipe: Recipe,
        ingredientsToAdd: List<RecipeIngredient>,
        targetServings: Int
    ) {
        if (ingredientsToAdd.isEmpty()) {
            emitSnackbar("All ingredients are already checked off.")
            return
        }
        viewModelScope.launch {
            val prefs = preferences.value
            val copy = LocalizedCopy.forVariant(prefs.englishVariant)
            val items = ingredientsToAdd.map { ing ->
                val converted = UnitConverter.formatIngredient(
                    ingredient = ing,
                    sourceSystem = recipe.measurementSystem,
                    targetSystem = prefs.measurementSystem,
                    baseServings = recipe.servings,
                    targetServings = targetServings,
                    englishVariant = prefs.englishVariant,
                    approxLabel = copy.approxUnitLabel
                )
                val qty = buildString {
                    append(converted.amountText)
                    if (converted.unitText.isNotBlank()) {
                        append(" ").append(converted.unitText)
                    }
                    if (converted.isApproximateConversion) {
                        append(" (${copy.approxUnitLabel})")
                    }
                }.trim()
                ShoppingItem(
                    id = UUID.randomUUID().toString(),
                    name = ing.name,
                    quantityText = qty,
                    category = ing.category,
                    isChecked = false,
                    recipeSource = recipe.name
                )
            }
            repository.addShoppingItemsBatch(items)
            emitSnackbar("Added ${items.size} item(s) to Shopping List")
        }
    }

    fun assignMealPlan(day: DayOfWeekSlot, slot: MealSlotType, recipe: Recipe) {
        viewModelScope.launch {
            repository.assignMealPlan(day, slot, recipe)
            emitSnackbar("Planned ${recipe.name} for ${day.shortName} ${slot.displayName}")
        }
    }

    fun removeMealPlan(day: DayOfWeekSlot, slot: MealSlotType) {
        viewModelScope.launch {
            repository.removeMealPlan(day, slot)
            emitSnackbar("Removed ${day.shortName} ${slot.displayName}")
        }
    }

    fun addDayMealsToShoppingList(day: DayOfWeekSlot) {
        viewModelScope.launch {
            val dayEntries = mealPlans.value.filter { it.dayOfWeek == day }
            if (dayEntries.isEmpty()) {
                emitSnackbar("No meals planned for ${day.fullName}.")
                return@launch
            }
            val prefs = preferences.value
            val copy = LocalizedCopy.forVariant(prefs.englishVariant)
            val batch = mutableListOf<ShoppingItem>()
            dayEntries.forEach { entry ->
                val recipe = repository.getRecipeById(entry.recipeId) ?: return@forEach
                recipe.ingredients.forEach { ing ->
                    val converted = UnitConverter.formatIngredient(
                        ingredient = ing,
                        sourceSystem = recipe.measurementSystem,
                        targetSystem = prefs.measurementSystem,
                        baseServings = recipe.servings,
                        targetServings = recipe.servings,
                        englishVariant = prefs.englishVariant,
                        approxLabel = copy.approxUnitLabel
                    )
                    val qty = buildString {
                        append(converted.amountText)
                        if (converted.unitText.isNotBlank()) append(" ").append(converted.unitText)
                    }.trim()
                    batch.add(
                        ShoppingItem(
                            id = UUID.randomUUID().toString(),
                            name = ing.name,
                            quantityText = qty,
                            category = ing.category,
                            recipeSource = recipe.name
                        )
                    )
                }
            }
            repository.addShoppingItemsBatch(batch)
            emitSnackbar("Added ${batch.size} ingredients from ${day.fullName} to Shopping List")
        }
    }

    fun addShoppingItem(name: String, quantity: String, category: ShoppingCategory) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.addShoppingItem(name, quantity, category)
        }
    }

    fun updateShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateShoppingItem(item)
        }
    }

    fun toggleShoppingItem(id: String, checked: Boolean) {
        viewModelScope.launch {
            repository.toggleShoppingItemChecked(id, checked)
        }
    }

    fun deleteShoppingItem(id: String) {
        viewModelScope.launch {
            repository.deleteShoppingItem(id)
        }
    }

    fun clearCheckedShoppingItems() {
        viewModelScope.launch {
            repository.clearCheckedShoppingItems()
            emitSnackbar("Cleared purchased items")
        }
    }

    fun setMeasurementSystem(system: MeasurementSystem) {
        viewModelScope.launch { repository.setMeasurementSystem(system) }
    }

    fun setEnglishVariant(variant: EnglishVariant) {
        viewModelScope.launch { repository.setEnglishVariant(variant) }
    }

    fun setDietaryPreference(preference: DietaryPreference) {
        viewModelScope.launch { repository.setDietaryPreference(preference) }
    }

    fun toggleCommonAllergen(allergen: String) {
        viewModelScope.launch { repository.toggleCommonAllergen(allergen) }
    }

    fun addCustomAllergy(allergy: String) {
        if (allergy.isBlank()) return
        viewModelScope.launch { repository.addCustomAllergy(allergy) }
    }

    fun removeCustomAllergy(allergy: String) {
        viewModelScope.launch { repository.removeCustomAllergy(allergy) }
    }

    fun buildShareRecipeText(recipe: Recipe, targetServings: Int, prefs: UserPreferences): String {
        val copy = LocalizedCopy.forVariant(prefs.englishVariant)
        return buildString {
            appendLine(recipe.name)
            appendLine(recipe.description)
            appendLine()
            appendLine("Prep: ${recipe.prepTimeMinutes} min | Cook: ${recipe.cookTimeMinutes} min | Servings: $targetServings | Difficulty: ${recipe.difficulty.displayName}")
            appendLine("Units: ${prefs.measurementSystem.label}")
            appendLine()
            appendLine("Ingredients:")
            recipe.ingredients.forEach { ing ->
                val formatted = UnitConverter.formatIngredient(
                    ingredient = ing,
                    sourceSystem = recipe.measurementSystem,
                    targetSystem = prefs.measurementSystem,
                    baseServings = recipe.servings,
                    targetServings = targetServings,
                    englishVariant = prefs.englishVariant,
                    approxLabel = copy.approxUnitLabel
                )
                appendLine("• ${formatted.fullText}")
            }
            appendLine()
            appendLine("Steps:")
            recipe.steps.forEachIndexed { idx, step ->
                val convertedStep = UnitConverter.convertStepTemperatures(step, prefs.measurementSystem, copy.approxUnitLabel)
                appendLine("${idx + 1}. ${convertedStep.text}")
            }
            appendLine()
            appendLine("Estimated Nutrition (per serving): ~${recipe.nutrition.calories} kcal, ${recipe.nutrition.proteinGrams}g protein, ${recipe.nutrition.carbsGrams}g carbs, ${recipe.nutrition.fatGrams}g fat.")
            appendLine("Note: Nutrition values are estimates only, not medical advice. Always verify product labels for allergens.")
        }
    }

    fun buildShareShoppingListText(items: List<ShoppingItem>): String {
        val grouped = items.groupBy { it.category }
        return buildString {
            appendLine("PantryChef AI Shopping List")
            appendLine("---------------------------")
            ShoppingCategory.entries.forEach { cat ->
                val catItems = grouped[cat].orEmpty()
                if (catItems.isNotEmpty()) {
                    appendLine()
                    appendLine("[${cat.displayName}]")
                    catItems.forEach { item ->
                        val mark = if (item.isChecked) "[x]" else "[ ]"
                        val qty = if (item.quantityText.isNotBlank()) " — ${item.quantityText}" else ""
                        appendLine("$mark ${item.name}$qty")
                    }
                }
            }
        }
    }

    private fun emitSnackbar(message: String) {
        _snackbarEvents.tryEmit(message)
    }
}
