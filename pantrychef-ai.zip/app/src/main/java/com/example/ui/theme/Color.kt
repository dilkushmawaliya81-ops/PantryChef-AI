package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Charcoal / Near-Black Surfaces
val CharcoalBackground = Color(0xFF0E1210)
val CharcoalSurface = Color(0xFF151B17)
val CharcoalSurfaceElevated = Color(0xFF1C241F)
val CharcoalSurfaceHighest = Color(0xFF253029)
val CharcoalOutline = Color(0xFF334138)
val CharcoalOutlineSubtle = Color(0xFF232D27)

// Fresh Herb Green Accents
val FreshGreen = Color(0xFF4ADE80)
val FreshGreenBright = Color(0xFF6EE79D)
val FreshGreenDark = Color(0xFF16A34A)
val FreshGreenContainer = Color(0xFF133320)
val OnFreshGreen = Color(0xFF062612)
val OnFreshGreenContainer = Color(0xFFA7F3C0)

// Warm Citrus / Terracotta Orange Highlights
val WarmOrange = Color(0xFFFB923C)
val WarmOrangeSoft = Color(0xFFFDBA74)
val WarmOrangeContainer = Color(0xFF3B2110)
val OnWarmOrange = Color(0xFF2E1200)
val OnWarmOrangeContainer = Color(0xFFFFD8B8)

// Text & Semantic Colors
val TextPrimary = Color(0xFFF4F7F4)
val TextSecondary = Color(0xFFB3C2B7)
val TextMuted = Color(0xFF7D8F82)
val ErrorCoral = Color(0xFFF87171)
val ErrorContainer = Color(0xFF3F1616)
val OnErrorContainer = Color(0xFFFECACA)
val WarningAmber = Color(0xFFFBBF24)
val WarningContainer = Color(0xFF38290C)
