package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.domain.LocalizedCopy
import com.example.domain.ShoppingCategory
import com.example.domain.ShoppingItem
import com.example.domain.UserPreferences
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.OnFreshGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShoppingListScreen(
    items: List<ShoppingItem>,
    preferences: UserPreferences,
    onAddItem: (String, String, ShoppingCategory) -> Unit,
    onUpdateItem: (ShoppingItem) -> Unit,
    onToggleChecked: (String, Boolean) -> Unit,
    onDeleteItem: (String) -> Unit,
    onClearChecked: () -> Unit,
    onBuildShareText: (List<ShoppingItem>) -> String,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val copy = LocalizedCopy.forVariant(preferences.englishVariant)

    var newName by rememberSaveable { mutableStateOf("") }
    var newQty by rememberSaveable { mutableStateOf("") }
    var newCategory by rememberSaveable { mutableStateOf(ShoppingCategory.PRODUCE) }
    var editingItem by remember { mutableStateOf<ShoppingItem?>(null) }

    val grouped = remember(items) { items.groupBy { it.category } }
    val hasChecked = remember(items) { items.any { it.isChecked } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("shopping_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Shopping List",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = copy.organiseShoppingList,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                    if (items.isNotEmpty()) {
                        Row {
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(onBuildShareText(items)))
                                    onShowMessage("Shopping list copied to clipboard")
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("copy_shopping_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ContentCopy,
                                    contentDescription = "Copy shopping list"
                                )
                            }
                            IconButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "PantryChef AI Shopping List")
                                        putExtra(Intent.EXTRA_TEXT, onBuildShareText(items))
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Shopping List"))
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("share_shopping_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Share,
                                    contentDescription = "Share shopping list"
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Add Item Card
        item {
            Card(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                border = BorderStroke(1.dp, CharcoalOutline)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            placeholder = { Text("Add item (e.g. Milk)") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("shopping_item_name_input")
                        )
                        OutlinedTextField(
                            value = newQty,
                            onValueChange = { newQty = it },
                            placeholder = { Text("Qty") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("shopping_item_qty_input")
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ShoppingCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = newCategory == cat,
                                onClick = { newCategory = cat },
                                label = { Text(cat.displayName) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                onAddItem(newName, newQty, newCategory)
                                newName = ""
                                newQty = ""
                            }
                        },
                        enabled = newName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FreshGreen,
                            contentColor = OnFreshGreen
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("add_shopping_item_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add to Shopping List")
                    }
                }
            }
        }

        if (hasChecked) {
            item {
                Row(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onClearChecked) {
                        Text("Clear Purchased Items", color = WarmOrange)
                    }
                }
            }
        }

        if (items.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Outlined.ShoppingCart,
                    title = "Your shopping list is empty",
                    subtitle = "Add items above or tap 'Add Missing to List' inside any recipe.",
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .testTag("shopping_empty_state")
                )
            }
        } else {
            ShoppingCategory.entries.forEach { category ->
                val catItems = grouped[category].orEmpty()
                if (catItems.isNotEmpty()) {
                    item(key = "header_${category.name}") {
                        Text(
                            text = "${category.displayName} (${catItems.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = WarmOrange,
                            modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth()
                        )
                    }
                    items(catItems, key = { it.id }) { item ->
                        Surface(
                            color = CharcoalSurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CharcoalOutline),
                            modifier = Modifier
                                .widthIn(max = 800.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onToggleChecked(item.id, !item.isChecked) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = item.isChecked,
                                    onCheckedChange = { onToggleChecked(item.id, it) },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = FreshGreen,
                                        checkmarkColor = OnFreshGreen
                                    )
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (item.isChecked) TextMuted else TextPrimary,
                                        textDecoration = if (item.isChecked) TextDecoration.LineThrough else TextDecoration.None
                                    )
                                    val meta = buildString {
                                        if (item.quantityText.isNotBlank()) append(item.quantityText)
                                        if (item.recipeSource.isNotBlank()) {
                                            if (isNotEmpty()) append(" • ")
                                            append(item.recipeSource)
                                        }
                                    }
                                    if (meta.isNotBlank()) {
                                        Text(
                                            text = meta,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { editingItem = item },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("edit_item_${item.name}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Edit,
                                        contentDescription = "Edit ${item.name}",
                                        tint = TextSecondary
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteItem(item.id) },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("delete_item_${item.name}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = "Delete ${item.name}",
                                        tint = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(72.dp).testTag("shopping_bottom_spacer")) }
    }

    val toEdit = editingItem
    if (toEdit != null) {
        var editName by remember(toEdit.id) { mutableStateOf(toEdit.name) }
        var editQty by remember(toEdit.id) { mutableStateOf(toEdit.quantityText) }
        var editCategory by remember(toEdit.id) { mutableStateOf(toEdit.category) }

        AlertDialog(
            onDismissRequest = { editingItem = null },
            containerColor = CharcoalSurfaceElevated,
            title = { Text("Edit Item") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Item name") },
                        singleLine = true,
                        modifier = Modifier.testTag("edit_shopping_item_name_input")
                    )
                    OutlinedTextField(
                        value = editQty,
                        onValueChange = { editQty = it },
                        label = { Text("Quantity") },
                        singleLine = true,
                        modifier = Modifier.testTag("edit_shopping_item_qty_input")
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ShoppingCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = editCategory == cat,
                                onClick = { editCategory = cat },
                                label = { Text(cat.displayName) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isNotBlank()) {
                            onUpdateItem(
                                toEdit.copy(
                                    name = editName.trim(),
                                    quantityText = editQty.trim(),
                                    category = editCategory
                                )
                            )
                            editingItem = null
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingItem = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
