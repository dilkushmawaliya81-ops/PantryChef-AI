package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.DietaryPreference
import com.example.domain.MealCategory
import com.example.domain.Recipe
import com.example.domain.UserPreferences
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.RecipeSummaryCard
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.OnWarmOrangeContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange
import com.example.ui.theme.WarmOrangeContainer

@Composable
fun DiscoverScreen(
    sampleRecipes: List<Recipe>,
    recentGenerated: List<Recipe>,
    favouritesIds: Set<String>,
    preferences: UserPreferences,
    onOpenRecipe: (Recipe) -> Unit,
    onToggleFavourite: (Recipe) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf<MealCategory?>(null) }
    var filterByActiveDiet by rememberSaveable { mutableStateOf(false) }

    val mergedRecipes = remember(sampleRecipes, recentGenerated, favouritesIds) {
        val combined = (recentGenerated + sampleRecipes).distinctBy { it.id }
        combined.map { it.copy(isFavourite = it.id in favouritesIds) }
    }

    val filteredRecipes = remember(
        mergedRecipes,
        searchQuery,
        selectedCategory,
        filterByActiveDiet,
        preferences.dietaryPreference
    ) {
        mergedRecipes.filter { recipe ->
            val matchesQuery = searchQuery.isBlank() ||
                recipe.name.contains(searchQuery, ignoreCase = true) ||
                recipe.description.contains(searchQuery, ignoreCase = true) ||
                recipe.ingredients.any { it.name.contains(searchQuery, ignoreCase = true) }

            val matchesCategory = selectedCategory == null || recipe.mealCategory == selectedCategory

            val matchesDiet = !filterByActiveDiet ||
                preferences.dietaryPreference == DietaryPreference.NONE ||
                preferences.dietaryPreference in recipe.dietaryTags

            matchesQuery && matchesCategory && matchesDiet
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Discover Recipes",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Offline-ready classic dishes & your recently generated AI creations.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by title or ingredient...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Search",
                            tint = TextSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Outlined.Clear,
                                    contentDescription = "Clear search"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FreshGreen,
                        unfocusedBorderColor = CharcoalOutline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("discover_search_input")
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { selectedCategory = null },
                            label = { Text("All") },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalSurfaceElevated,
                                labelColor = TextSecondary,
                                selectedContainerColor = FreshGreenContainer,
                                selectedLabelColor = OnFreshGreenContainer
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedCategory == null,
                                borderColor = CharcoalOutline,
                                selectedBorderColor = FreshGreen
                            )
                        )
                    }
                    items(MealCategory.entries) { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = if (isSelected) null else cat },
                            label = { Text(cat.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalSurfaceElevated,
                                labelColor = TextSecondary,
                                selectedContainerColor = WarmOrangeContainer,
                                selectedLabelColor = OnWarmOrangeContainer
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = CharcoalOutline,
                                selectedBorderColor = WarmOrange
                            )
                        )
                    }
                }

                if (preferences.dietaryPreference != DietaryPreference.NONE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(
                            selected = filterByActiveDiet,
                            onClick = { filterByActiveDiet = !filterByActiveDiet },
                            label = { Text("Match my diet: ${preferences.dietaryPreference.displayName}") },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalSurfaceElevated,
                                selectedContainerColor = FreshGreenContainer,
                                selectedLabelColor = OnFreshGreenContainer
                            )
                        )
                    }
                }
            }
        }

        if (filteredRecipes.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Outlined.RestaurantMenu,
                    title = "No matching recipes",
                    subtitle = "Try clearing your search or category filter to browse all offline recipes.",
                    actionLabel = "Reset Filters",
                    onAction = {
                        searchQuery = ""
                        selectedCategory = null
                        filterByActiveDiet = false
                    },
                    modifier = Modifier.widthIn(max = 800.dp)
                )
            }
        } else {
            items(filteredRecipes, key = { it.id }) { recipe ->
                RecipeSummaryCard(
                    recipe = recipe,
                    onClick = { onOpenRecipe(recipe) },
                    onToggleFavourite = { onToggleFavourite(recipe) },
                    modifier = Modifier.widthIn(max = 800.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}
