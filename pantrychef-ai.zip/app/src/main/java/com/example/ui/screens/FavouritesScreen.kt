package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.LocalizedCopy
import com.example.domain.Recipe
import com.example.domain.UserPreferences
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.RecipeSummaryCard
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FavouritesScreen(
    favourites: List<Recipe>,
    recentGenerated: List<Recipe>,
    recentlyViewed: List<Recipe>,
    preferences: UserPreferences,
    onOpenRecipe: (Recipe) -> Unit,
    onToggleFavourite: (Recipe) -> Unit,
    onExploreDiscover: () -> Unit,
    modifier: Modifier = Modifier
) {
    val copy = LocalizedCopy.forVariant(preferences.englishVariant)
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val historyList = (recentGenerated + recentlyViewed).distinctBy { it.id }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = copy.favouritesTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        label = { Text("${copy.navFavourites} (${favourites.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = CharcoalSurfaceElevated,
                            labelColor = TextSecondary,
                            selectedContainerColor = FreshGreenContainer,
                            selectedLabelColor = OnFreshGreenContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedTab == 0,
                            borderColor = CharcoalOutline,
                            selectedBorderColor = FreshGreen
                        ),
                        modifier = Modifier.testTag("tab_favourites")
                    )
                    FilterChip(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        label = { Text("Recent History (${historyList.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = CharcoalSurfaceElevated,
                            labelColor = TextSecondary,
                            selectedContainerColor = FreshGreenContainer,
                            selectedLabelColor = OnFreshGreenContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedTab == 1,
                            borderColor = CharcoalOutline,
                            selectedBorderColor = FreshGreen
                        ),
                        modifier = Modifier.testTag("tab_recent_history")
                    )
                }
            }
        }

        if (selectedTab == 0) {
            if (favourites.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Outlined.FavoriteBorder,
                        title = copy.favouritesEmptyTitle,
                        subtitle = copy.favouritesEmptyHint,
                        actionLabel = "Discover Recipes",
                        onAction = onExploreDiscover,
                        modifier = Modifier
                            .widthIn(max = 800.dp)
                            .testTag("favourites_empty_state")
                    )
                }
            } else {
                items(favourites, key = { it.id }) { recipe ->
                    RecipeSummaryCard(
                        recipe = recipe,
                        onClick = { onOpenRecipe(recipe) },
                        onToggleFavourite = { onToggleFavourite(recipe) },
                        modifier = Modifier.widthIn(max = 800.dp)
                    )
                }
            }
        } else {
            if (historyList.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Outlined.History,
                        title = "No recipe history yet",
                        subtitle = "Recipes you generate with AI or view in Discover appear here automatically.",
                        actionLabel = "Discover Recipes",
                        onAction = onExploreDiscover,
                        modifier = Modifier.widthIn(max = 800.dp)
                    )
                }
            } else {
                items(historyList, key = { it.id }) { recipe ->
                    RecipeSummaryCard(
                        recipe = recipe,
                        onClick = { onOpenRecipe(recipe) },
                        onToggleFavourite = { onToggleFavourite(recipe) },
                        modifier = Modifier.widthIn(max = 800.dp)
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}
