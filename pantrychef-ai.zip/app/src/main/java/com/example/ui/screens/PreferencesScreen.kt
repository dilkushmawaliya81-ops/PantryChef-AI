package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.domain.CommonAllergens
import com.example.domain.DietaryPreference
import com.example.domain.EnglishVariant
import com.example.domain.LocalizedCopy
import com.example.domain.MeasurementSystem
import com.example.domain.UserPreferences
import com.example.ui.components.AllergenWarningBanner
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.OnWarmOrangeContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange
import com.example.ui.theme.WarmOrangeContainer

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PreferencesScreen(
    preferences: UserPreferences,
    onBack: () -> Unit,
    onSetMeasurementSystem: (MeasurementSystem) -> Unit,
    onSetEnglishVariant: (EnglishVariant) -> Unit,
    onSetDietaryPreference: (DietaryPreference) -> Unit,
    onToggleCommonAllergen: (String) -> Unit,
    onAddCustomAllergy: (String) -> Unit,
    onRemoveCustomAllergy: (String) -> Unit,
    onOpenPrivacyAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val copy = LocalizedCopy.forVariant(preferences.englishVariant)
    var customAllergyInput by rememberSaveable { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CharcoalBackground,
        topBar = {
            TopAppBar(
                title = { Text(copy.customisePreferences) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CharcoalBackground,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Measurement & Region Card
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Measurement System",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MeasurementSystem.entries.forEach { system ->
                                val selected = preferences.measurementSystem == system
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSetMeasurementSystem(system) },
                                    label = { Text(system.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FreshGreenContainer,
                                        selectedLabelColor = OnFreshGreenContainer
                                    ),
                                    modifier = Modifier.testTag("pref_unit_${system.name}")
                                )
                            }
                        }
                        Text(
                            text = if (preferences.measurementSystem == MeasurementSystem.US_CUSTOMARY) {
                                copy.measurementUsDescription
                            } else {
                                copy.measurementMetricDescription
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )

                        Text(
                            text = "English Spelling & Region",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            EnglishVariant.entries.forEach { variant ->
                                val selected = preferences.englishVariant == variant
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSetEnglishVariant(variant) },
                                    label = { Text(variant.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WarmOrangeContainer,
                                        selectedLabelColor = OnWarmOrangeContainer
                                    ),
                                    modifier = Modifier.testTag("pref_lang_${variant.name}")
                                )
                            }
                        }
                    }
                }
            }

            // Dietary Preferences
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Dietary Preference",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DietaryPreference.entries.forEach { diet ->
                                val selected = preferences.dietaryPreference == diet
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSetDietaryPreference(diet) },
                                    label = { Text(diet.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FreshGreenContainer,
                                        selectedLabelColor = OnFreshGreenContainer
                                    ),
                                    modifier = Modifier.testTag("pref_diet_${diet.name}")
                                )
                            }
                        }
                    }
                }
            }

            // Allergies Card
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Allergies & Intolerances",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CommonAllergens.list.forEach { allergen ->
                                val selected = allergen in preferences.selectedAllergens
                                FilterChip(
                                    selected = selected,
                                    onClick = { onToggleCommonAllergen(allergen) },
                                    label = { Text(allergen) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WarmOrangeContainer,
                                        selectedLabelColor = OnWarmOrangeContainer
                                    ),
                                    modifier = Modifier.testTag("allergen_chip_$allergen")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = customAllergyInput,
                                onValueChange = { customAllergyInput = it },
                                placeholder = { Text("Add custom allergy (e.g. kiwi)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        if (customAllergyInput.isNotBlank()) {
                                            onAddCustomAllergy(customAllergyInput)
                                            customAllergyInput = ""
                                        }
                                    }
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("custom_allergy_input")
                            )
                            Button(
                                onClick = {
                                    if (customAllergyInput.isNotBlank()) {
                                        onAddCustomAllergy(customAllergyInput)
                                        customAllergyInput = ""
                                    }
                                },
                                enabled = customAllergyInput.isNotBlank(),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = "Add custom allergy")
                            }
                        }

                        if (preferences.customAllergies.isNotEmpty()) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                preferences.customAllergies.forEach { custom ->
                                    InputChip(
                                        selected = true,
                                        onClick = { onRemoveCustomAllergy(custom) },
                                        label = { Text(custom) },
                                        trailingIcon = {
                                            Icon(
                                                imageVector = Icons.Filled.Close,
                                                contentDescription = "Remove $custom",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        AllergenWarningBanner(matchedAllergies = emptyList())
                    }
                }
            }

            // Nutrition & Privacy Link
            item {
                Card(
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable(onClick = onOpenPrivacyAbout)
                        .testTag("open_privacy_about_card"),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PrivacyTip,
                            contentDescription = null,
                            tint = FreshGreen
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Privacy Policy & About PantryChef AI",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Local storage, AI generation disclosures, and safety notes",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = TextMuted
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Nutrition values shown in PantryChef AI are estimates only and are not medical advice.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    modifier = Modifier.widthIn(max = 800.dp)
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}
