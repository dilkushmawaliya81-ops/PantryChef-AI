package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.outlined.BakeryDining
import androidx.compose.material.icons.outlined.DinnerDining
import androidx.compose.material.icons.outlined.LocalCafe
import androidx.compose.material.icons.outlined.LunchDining
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.MealCategory
import com.example.domain.Recipe
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnErrorContainer
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.OnWarmOrangeContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange
import com.example.ui.theme.WarmOrangeContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningContainer
import kotlinx.coroutines.delay

@Composable
fun VectorSplashOverlay(
    visible: Boolean,
    onFinished: () -> Unit
) {
    val scale = remember { Animatable(0.84f) }
    LaunchedEffect(visible) {
        if (visible) {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
            delay(550)
            onFinished()
        }
    }

    AnimatedVisibility(
        visible = visible,
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF17271E), CharcoalBackground),
                        radius = 900f
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.scale(scale.value)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_pantry_chef_logo),
                    contentDescription = "PantryChef AI logo",
                    modifier = Modifier.size(116.dp)
                )
                Text(
                    text = "PantryChef AI",
                    style = MaterialTheme.typography.displaySmall,
                    color = TextPrimary
                )
                Text(
                    text = "Cook smarter with what's already home",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
fun RecipeVectorIllustrationBanner(
    mealCategory: MealCategory,
    isAiGenerated: Boolean,
    modifier: Modifier = Modifier
) {
    val (accentA, accentB, icon) = when (mealCategory) {
        MealCategory.BREAKFAST -> Triple(WarmOrange, FreshGreen, Icons.Outlined.LocalCafe)
        MealCategory.LUNCH -> Triple(FreshGreen, Color(0xFF34D399), Icons.Outlined.LunchDining)
        MealCategory.DINNER -> Triple(WarmOrange, Color(0xFFEA580C), Icons.Outlined.DinnerDining)
        MealCategory.SNACK -> Triple(FreshGreen, WarmOrange, Icons.Outlined.BakeryDining)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(CharcoalSurfaceElevated)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(
                        accentA.copy(alpha = 0.24f),
                        Color(0xFF151E19),
                        accentB.copy(alpha = 0.22f)
                    )
                )
            )
            drawCircle(
                color = accentA.copy(alpha = 0.14f),
                radius = size.minDimension * 0.65f,
                center = Offset(size.width * 0.85f, size.height * 0.2f)
            )
            drawCircle(
                color = accentB.copy(alpha = 0.12f),
                radius = size.minDimension * 0.45f,
                center = Offset(size.width * 0.15f, size.height * 0.9f)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = accentA.copy(alpha = 0.18f),
                    shape = CircleShape,
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = mealCategory.displayName,
                            tint = accentA,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = mealCategory.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = if (isAiGenerated) "AI Tailored Recipe" else "Offline Chef Classic",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            if (isAiGenerated) {
                Surface(
                    color = FreshGreenContainer,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, FreshGreen.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = "AI Generated",
                            tint = FreshGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Gemini",
                            style = MaterialTheme.typography.labelSmall,
                            color = OnFreshGreenContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecipeSummaryCard(
    recipe: Recipe,
    onClick: () -> Unit,
    onToggleFavourite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("recipe_card_${recipe.id}"),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
        border = BorderStroke(1.dp, CharcoalOutline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            RecipeVectorIllustrationBanner(
                mealCategory = recipe.mealCategory,
                isAiGenerated = recipe.isAiGenerated,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(78.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = recipe.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = recipe.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = onToggleFavourite,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("fav_button_${recipe.id}")
                ) {
                    Icon(
                        imageVector = if (recipe.isFavourite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = if (recipe.isFavourite) "Remove favourite" else "Save favourite",
                        tint = if (recipe.isFavourite) WarmOrange else TextSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                InfoPill(
                    icon = Icons.Outlined.Schedule,
                    text = "${recipe.totalTimeMinutes} min",
                    containerColor = FreshGreenContainer,
                    contentColor = OnFreshGreenContainer
                )
                InfoPill(
                    text = recipe.difficulty.displayName,
                    containerColor = WarmOrangeContainer,
                    contentColor = OnWarmOrangeContainer
                )
                InfoPill(
                    text = "${recipe.servings} servings",
                    containerColor = Color(0xFF232C26),
                    contentColor = TextSecondary
                )
            }
        }
    }
}

@Composable
fun InfoPill(
    text: String,
    containerColor: Color,
    contentColor: Color,
    icon: ImageVector? = null
) {
    Surface(
        color = containerColor,
        shape = RoundedCornerShape(50)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(14.dp)
                )
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor
            )
        }
    }
}

@Composable
fun ErrorRetryCard(
    message: String,
    onRetry: () -> Unit,
    onBrowseSamples: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ErrorContainer),
        border = BorderStroke(1.dp, ErrorCoral.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.WarningAmber,
                    contentDescription = "Error",
                    tint = ErrorCoral
                )
                Text(
                    text = "Recipe Generation Unavailable",
                    style = MaterialTheme.typography.titleMedium,
                    color = OnErrorContainer
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = OnErrorContainer
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WarmOrange,
                        contentColor = Color(0xFF2B1200)
                    ),
                    modifier = Modifier.testTag("retry_ai_button")
                ) {
                    Text("Retry")
                }
                OutlinedButton(
                    onClick = onBrowseSamples,
                    border = BorderStroke(1.dp, OnErrorContainer.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("fallback_samples_button")
                ) {
                    Text("Sample Recipes", color = OnErrorContainer)
                }
            }
        }
    }
}

@Composable
fun AllergenWarningBanner(
    matchedAllergies: List<String>,
    modifier: Modifier = Modifier
) {
    val hasMatch = matchedAllergies.isNotEmpty()
    val bgColor = if (hasMatch) ErrorContainer else WarningContainer
    val borderColor = if (hasMatch) ErrorCoral else WarningAmber
    val textColor = if (hasMatch) OnErrorContainer else Color(0xFFFDE68A)

    Surface(
        color = bgColor,
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.55f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Outlined.WarningAmber,
                contentDescription = "Allergen warning",
                tint = borderColor,
                modifier = Modifier.size(20.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (hasMatch) {
                    Text(
                        text = "Allergy Match Alert: ${matchedAllergies.joinToString(", ")}",
                        style = MaterialTheme.typography.titleSmall,
                        color = textColor,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Always check product labels and watch for cross-contamination. Recipes cannot be guaranteed allergen-free unless every ingredient label is verified.",
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor
                )
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
        border = BorderStroke(1.dp, CharcoalOutline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = FreshGreenContainer,
                shape = CircleShape,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = FreshGreen,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}
