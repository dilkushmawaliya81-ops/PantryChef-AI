package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.domain.DayOfWeekSlot
import com.example.domain.LocalizedCopy
import com.example.domain.MealSlotType
import com.example.domain.MeasurementSystem
import com.example.domain.Recipe
import com.example.domain.RecipeIngredient
import com.example.domain.UnitConverter
import com.example.domain.UserPreferences
import com.example.ui.components.AllergenWarningBanner
import com.example.ui.components.InfoPill
import com.example.ui.components.RecipeVectorIllustrationBanner
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreen
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.OnWarmOrangeContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange
import com.example.ui.theme.WarmOrangeContainer

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RecipeDetailScreen(
    recipe: Recipe,
    preferences: UserPreferences,
    onBack: () -> Unit,
    onToggleFavourite: () -> Unit,
    onAddToShoppingList: (List<RecipeIngredient>, Int) -> Unit,
    onAssignToMealPlan: (DayOfWeekSlot, MealSlotType) -> Unit,
    onGenerateAnother: () -> Unit,
    onBuildShareText: (Recipe, Int, UserPreferences) -> String,
    onToggleMeasurementSystem: (MeasurementSystem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val copy = LocalizedCopy.forVariant(preferences.englishVariant)
    var targetServings by rememberSaveable(recipe.id) { mutableIntStateOf(recipe.servings.coerceAtLeast(1)) }
    val checkedIngredients = remember(recipe.id) { mutableStateMapOf<Int, Boolean>() }
    val completedSteps = remember(recipe.id) { mutableStateMapOf<Int, Boolean>() }
    var showMealPlanDialog by remember { mutableStateOf(false) }

    val matchedAllergies = remember(recipe, preferences.allAllergies) {
        val haystack = (recipe.allergenInfo + recipe.ingredients.map { it.name }).joinToString(" ").lowercase()
        preferences.allAllergies.filter { allergy ->
            val keywords = allergy.lowercase().split("/", " ").map { it.trim() }.filter { it.length >= 3 }
            keywords.any { haystack.contains(it) }
        }
    }

    val hasAnyConversion = remember(recipe, preferences.measurementSystem, targetServings) {
        recipe.ingredients.any { ing ->
            UnitConverter.formatIngredient(
                ingredient = ing,
                sourceSystem = recipe.measurementSystem,
                targetSystem = preferences.measurementSystem,
                baseServings = recipe.servings,
                targetServings = targetServings,
                englishVariant = preferences.englishVariant,
                approxLabel = copy.approxUnitLabel
            ).isApproximateConversion
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CharcoalBackground,
        topBar = {
            TopAppBar(
                title = { Text("Recipe Details", maxLines = 1) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onToggleFavourite,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_favourite_button")
                    ) {
                        Icon(
                            imageVector = if (recipe.isFavourite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (recipe.isFavourite) copy.removeFromFavourites else copy.addToFavourites,
                            tint = if (recipe.isFavourite) WarmOrange else TextPrimary
                        )
                    }
                    IconButton(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, recipe.name)
                                putExtra(Intent.EXTRA_TEXT, onBuildShareText(recipe, targetServings, preferences))
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Recipe"))
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_share_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Share,
                            contentDescription = "Share recipe"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CharcoalBackground,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Banner + Title
            item {
                Column(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    RecipeVectorIllustrationBanner(
                        mealCategory = recipe.mealCategory,
                        isAiGenerated = recipe.isAiGenerated,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(104.dp)
                    )
                    Text(
                        text = recipe.name,
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        modifier = Modifier.testTag("detail_recipe_title")
                    )
                    Text(
                        text = recipe.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        InfoPill(
                            text = "Prep: ${recipe.prepTimeMinutes} min",
                            containerColor = FreshGreenContainer,
                            contentColor = OnFreshGreenContainer
                        )
                        InfoPill(
                            text = "Cook: ${recipe.cookTimeMinutes} min",
                            containerColor = FreshGreenContainer,
                            contentColor = OnFreshGreenContainer
                        )
                        InfoPill(
                            text = recipe.difficulty.displayName,
                            containerColor = WarmOrangeContainer,
                            contentColor = OnWarmOrangeContainer
                        )
                    }
                }
            }

            // Servings & Unit Switcher Card
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Servings",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Adjust to scale ingredient quantities",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = { if (targetServings > 1) targetServings-- },
                                    enabled = targetServings > 1,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("servings_decrease")
                                ) {
                                    Icon(Icons.Filled.Remove, contentDescription = "Decrease servings")
                                }
                                Text(
                                    text = "$targetServings",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = FreshGreen,
                                    modifier = Modifier.testTag("servings_count")
                                )
                                IconButton(
                                    onClick = { if (targetServings < 16) targetServings++ },
                                    enabled = targetServings < 16,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("servings_increase")
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = "Increase servings")
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Units:",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MeasurementSystem.entries.forEach { sys ->
                                    FilterChip(
                                        selected = preferences.measurementSystem == sys,
                                        onClick = { onToggleMeasurementSystem(sys) },
                                        label = { Text(sys.label) },
                                        modifier = Modifier.testTag("detail_unit_${sys.name}")
                                    )
                                }
                            }
                        }

                        if (hasAnyConversion) {
                            Text(
                                text = "Converted from ${recipe.measurementSystem.label} — values marked (${copy.approxUnitLabel}) are approximate conversions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmOrange
                            )
                        }
                    }
                }
            }

            // Allergen Warning Banner
            item {
                AllergenWarningBanner(
                    matchedAllergies = matchedAllergies,
                    modifier = Modifier.widthIn(max = 800.dp)
                )
            }

            // Ingredients Checklist Header & Actions
            item {
                Column(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ingredients",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "Check off what you have",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }

            itemsIndexed(recipe.ingredients) { index, ing ->
                val isChecked = checkedIngredients[index] == true
                val formatted = UnitConverter.formatIngredient(
                    ingredient = ing,
                    sourceSystem = recipe.measurementSystem,
                    targetSystem = preferences.measurementSystem,
                    baseServings = recipe.servings,
                    targetServings = targetServings,
                    englishVariant = preferences.englishVariant,
                    approxLabel = copy.approxUnitLabel
                )
                Surface(
                    color = CharcoalSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CharcoalOutline),
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { checkedIngredients[index] = !isChecked }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { checkedIngredients[index] = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = FreshGreen,
                                checkmarkColor = OnFreshGreen
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = formatted.fullText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (isChecked) TextMuted else TextPrimary,
                            textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Shopping List & Meal Planner Buttons
            item {
                Column(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val missing = recipe.ingredients.filterIndexed { idx, _ ->
                                    checkedIngredients[idx] != true
                                }
                                onAddToShoppingList(missing, targetServings)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FreshGreen,
                                contentColor = OnFreshGreen
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("add_to_shopping_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingCart,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Missing to List")
                        }

                        OutlinedButton(
                            onClick = { showMealPlanDialog = true },
                            border = BorderStroke(1.dp, WarmOrange),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("add_to_planner_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CalendarMonth,
                                contentDescription = null,
                                tint = WarmOrange,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Plan", color = WarmOrange)
                        }
                    }
                }
            }

            // Cooking Steps
            item {
                Text(
                    text = "Cooking Instructions",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary,
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth()
                )
            }

            itemsIndexed(recipe.steps) { index, step ->
                val done = completedSteps[index] == true
                val convertedStep = UnitConverter.convertStepTemperatures(
                    stepText = step,
                    targetSystem = preferences.measurementSystem,
                    approxLabel = copy.approxUnitLabel
                )
                Card(
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { completedSteps[index] = !done },
                    colors = CardDefaults.cardColors(
                        containerColor = if (done) CharcoalSurface else CharcoalSurfaceElevated
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (done) FreshGreen.copy(alpha = 0.45f) else CharcoalOutline
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Surface(
                            color = if (done) FreshGreen else WarmOrangeContainer,
                            shape = CircleShape,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (done) OnFreshGreen else OnWarmOrangeContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = convertedStep.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (done) TextMuted else TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = if (done) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                            contentDescription = if (done) "Step completed" else "Mark step complete",
                            tint = if (done) FreshGreen else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Nutrition Estimates Card
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Estimated Nutrition (Per Serving)",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            NutritionStat("Calories", "${recipe.nutrition.calories} kcal")
                            NutritionStat("Protein", "${recipe.nutrition.proteinGrams} g")
                            NutritionStat("Carbs", "${recipe.nutrition.carbsGrams} g")
                            NutritionStat("Fat", "${recipe.nutrition.fatGrams} g")
                            NutritionStat(copy.fibreLabel, "${recipe.nutrition.fiberGrams} g")
                        }
                        Text(
                            text = "Disclaimer: Nutrition values are estimates only and are not medical or dietary advice.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }

            // Allergens, Substitutions, Storage
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Allergen Information",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        recipe.allergenInfo.forEach { info ->
                            Text("• $info", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }

                        if (recipe.substitutions.isNotEmpty()) {
                            Text(
                                text = copy.flavourNote,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            recipe.substitutions.forEach { sub ->
                                Text("• $sub", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                            }
                        }

                        Text(
                            text = "Storage Suggestions",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = recipe.storageSuggestions,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Generate Another Recipe CTA
            item {
                OutlinedButton(
                    onClick = onGenerateAnother,
                    border = BorderStroke(1.dp, FreshGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .widthIn(max = 800.dp)
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_another_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = FreshGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Another Recipe", color = FreshGreen)
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (showMealPlanDialog) {
        var selectedDay by remember { mutableStateOf(DayOfWeekSlot.MONDAY) }
        var selectedSlot by remember { mutableStateOf(MealSlotType.DINNER) }

        AlertDialog(
            onDismissRequest = { showMealPlanDialog = false },
            containerColor = CharcoalSurfaceElevated,
            title = { Text("Add to Meal Planner") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select Day:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DayOfWeekSlot.entries.forEach { day ->
                            FilterChip(
                                selected = selectedDay == day,
                                onClick = { selectedDay = day },
                                label = { Text(day.shortName) }
                            )
                        }
                    }
                    Text("Select Meal Slot:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MealSlotType.entries.forEach { slot ->
                            FilterChip(
                                selected = selectedSlot == slot,
                                onClick = { selectedSlot = slot },
                                label = { Text(slot.displayName) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onAssignToMealPlan(selectedDay, selectedSlot)
                    showMealPlanDialog = false
                }) {
                    Text("Save to Plan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMealPlanDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun NutritionStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            color = FreshGreen,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}
