package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val PantryChefDarkColorScheme = darkColorScheme(
    primary = FreshGreen,
    onPrimary = OnFreshGreen,
    primaryContainer = FreshGreenContainer,
    onPrimaryContainer = OnFreshGreenContainer,
    secondary = WarmOrange,
    onSecondary = OnWarmOrange,
    secondaryContainer = WarmOrangeContainer,
    onSecondaryContainer = OnWarmOrangeContainer,
    tertiary = FreshGreenBright,
    onTertiary = OnFreshGreen,
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = CharcoalSurface,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = CharcoalBackground,
    surfaceContainerLow = CharcoalSurface,
    surfaceContainer = CharcoalSurfaceElevated,
    surfaceContainerHigh = CharcoalSurfaceHighest,
    outline = CharcoalOutline,
    outlineVariant = CharcoalOutlineSubtle,
    error = ErrorCoral,
    onError = OnFreshGreen,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer
)

val PantryChefShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PantryChefTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PantryChefDarkColorScheme,
        typography = Typography,
        shapes = PantryChefShapes,
        content = content
    )
}
