package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Kitchen
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.DietaryPreference
import com.example.domain.ExamplePantryIngredients
import com.example.domain.MealCategory
import com.example.domain.Recipe
import com.example.domain.UserPreferences
import com.example.ui.AiGenerationUiState
import com.example.ui.components.ErrorRetryCard
import com.example.ui.components.InfoPill
import com.example.ui.components.RecipeSummaryCard
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.OnFreshGreen
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.OnWarmOrangeContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange
import com.example.ui.theme.WarmOrangeContainer

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    ingredients: List<String>,
    selectedMealCategory: MealCategory?,
    preferences: UserPreferences,
    aiState: AiGenerationUiState,
    recentlyViewed: List<Recipe>,
    onAddIngredient: (String) -> Unit,
    onRemoveIngredient: (String) -> Unit,
    onToggleExampleIngredient: (String) -> Unit,
    onClearIngredients: () -> Unit,
    onSelectMealCategory: (MealCategory?) -> Unit,
    onGenerateRecipes: () -> Unit,
    onSelectDietaryPreference: (DietaryPreference) -> Unit,
    onOpenPreferences: () -> Unit,
    onOpenDiscover: () -> Unit,
    onOpenRecipe: (Recipe) -> Unit,
    onToggleFavourite: (Recipe) -> Unit,
    onDismissAiResults: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    val remainingAi = (UserPreferences.DAILY_AI_LIMIT - preferences.dailyAiCount).coerceAtLeast(0)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = FreshGreenContainer,
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Kitchen,
                                contentDescription = null,
                                tint = FreshGreen,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "PantryChef AI",
                                style = MaterialTheme.typography.labelMedium,
                                color = OnFreshGreenContainer
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenPreferences,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Preferences and Dietary Settings",
                            tint = TextSecondary
                        )
                    }
                }

                Text(
                    text = "What's in your kitchen?",
                    style = MaterialTheme.typography.displaySmall,
                    color = TextPrimary,
                    modifier = Modifier.testTag("home_welcome_heading")
                )
                Text(
                    text = "Add ingredients you have on hand and generate up to 3 tailored recipes.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Pantry Input Card
        item {
            Card(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                border = BorderStroke(1.dp, CharcoalOutline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("e.g. eggs, tomatoes, chicken") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    if (inputText.isNotBlank()) {
                                        onAddIngredient(inputText)
                                        inputText = ""
                                    }
                                }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = FreshGreen,
                                unfocusedBorderColor = CharcoalOutline,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ingredient_input_field")
                        )
                        Button(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    onAddIngredient(inputText)
                                    inputText = ""
                                }
                            },
                            enabled = inputText.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("add_ingredient_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "Add ingredient"
                            )
                        }
                    }

                    if (ingredients.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Your ingredients (${ingredients.size})",
                                style = MaterialTheme.typography.labelLarge,
                                color = FreshGreen
                            )
                            TextButton(onClick = onClearIngredients) {
                                Text("Clear all", color = TextSecondary)
                            }
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ingredients.forEach { ing ->
                                InputChip(
                                    selected = true,
                                    onClick = { onRemoveIngredient(ing) },
                                    label = { Text(ing) },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = "Remove $ing",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    colors = InputChipDefaults.inputChipColors(
                                        selectedContainerColor = FreshGreenContainer,
                                        selectedLabelColor = OnFreshGreenContainer,
                                        selectedTrailingIconColor = FreshGreen
                                    ),
                                    modifier = Modifier.testTag("selected_chip_$ing")
                                )
                            }
                        }
                    }

                    Text(
                        text = "Quick-add pantry staples:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ExamplePantryIngredients.list.forEach { sampleIng ->
                            val isSelected = ingredients.any { it.equals(sampleIng, ignoreCase = true) }
                            FilterChip(
                                selected = isSelected,
                                onClick = { onToggleExampleIngredient(sampleIng) },
                                label = { Text(sampleIng) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalSurface,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = FreshGreenContainer,
                                    selectedLabelColor = OnFreshGreenContainer
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = CharcoalOutline,
                                    selectedBorderColor = FreshGreen
                                ),
                                modifier = Modifier.testTag("example_chip_$sampleIng")
                            )
                        }
                    }

                    // Meal category selector
                    Text(
                        text = "Meal type (optional):",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(MealCategory.entries) { category ->
                            val selected = selectedMealCategory == category
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectMealCategory(category) },
                                label = { Text(category.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalSurface,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = WarmOrangeContainer,
                                    selectedLabelColor = OnWarmOrangeContainer
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = CharcoalOutline,
                                    selectedBorderColor = WarmOrange
                                ),
                                modifier = Modifier.testTag("meal_category_${category.name}")
                            )
                        }
                    }

                    Button(
                        onClick = onGenerateRecipes,
                        enabled = aiState !is AiGenerationUiState.Loading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FreshGreen,
                            contentColor = OnFreshGreen
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_recipes_button")
                    ) {
                        if (aiState is AiGenerationUiState.Loading) {
                            CircularProgressIndicator(
                                color = OnFreshGreen,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Crafting Recipes...", style = MaterialTheme.typography.titleSmall)
                        } else {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate Recipes", style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$remainingAi of ${UserPreferences.DAILY_AI_LIMIT} free AI generations left today",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (remainingAi == 0) WarmOrange else TextMuted
                        )
                        Text(
                            text = preferences.measurementSystem.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // AI Result / Error Section
        item {
            AnimatedVisibility(visible = aiState !is AiGenerationUiState.Idle) {
                Column(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (aiState) {
                        is AiGenerationUiState.Loading -> {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                                border = BorderStroke(1.dp, FreshGreen.copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(
                                        color = FreshGreen,
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.5.dp
                                    )
                                    Column {
                                        Text(
                                            text = "Generating recipes with Gemini...",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = "Checking dietary filters, units, and nutrition estimates.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }

                        is AiGenerationUiState.Error -> {
                            ErrorRetryCard(
                                message = aiState.message,
                                onRetry = onGenerateRecipes,
                                onBrowseSamples = onOpenDiscover
                            )
                        }

                        is AiGenerationUiState.Success -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AI Recipes for You (${aiState.recipes.size})",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = FreshGreen
                                )
                                TextButton(onClick = onDismissAiResults) {
                                    Text("Hide", color = TextSecondary)
                                }
                            }
                            aiState.recipes.forEach { recipe ->
                                RecipeSummaryCard(
                                    recipe = recipe,
                                    onClick = { onOpenRecipe(recipe) },
                                    onToggleFavourite = { onToggleFavourite(recipe) }
                                )
                            }
                        }

                        AiGenerationUiState.Idle -> Unit
                    }
                }
            }
        }

        // Dietary Preference Shortcuts
        item {
            Column(
                modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dietary Shortcuts",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    TextButton(onClick = onOpenPreferences) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (preferences.allAllergies.isEmpty()) "Allergies & Units"
                            else "${preferences.allAllergies.size} Allergy Filter(s)"
                        )
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(DietaryPreference.entries) { diet ->
                        val active = preferences.dietaryPreference == diet
                        FilterChip(
                            selected = active,
                            onClick = { onSelectDietaryPreference(diet) },
                            label = { Text(diet.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalSurfaceElevated,
                                labelColor = TextSecondary,
                                selectedContainerColor = FreshGreenContainer,
                                selectedLabelColor = OnFreshGreenContainer
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = active,
                                borderColor = CharcoalOutline,
                                selectedBorderColor = FreshGreen
                            ),
                            modifier = Modifier.testTag("diet_shortcut_${diet.name}")
                        )
                    }
                }
            }
        }

        // Recently Viewed Recipes
        if (recentlyViewed.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Recently Viewed",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recentlyViewed, key = { it.id }) { recipe ->
                            Card(
                                modifier = Modifier
                                    .width(230.dp)
                                    .clip(MaterialTheme.shapes.medium)
                                    .clickable { onOpenRecipe(recipe) },
                                colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                                border = BorderStroke(1.dp, CharcoalOutline)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = recipe.mealCategory.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WarmOrange
                                    )
                                    Text(
                                        text = recipe.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    InfoPill(
                                        icon = Icons.Outlined.Schedule,
                                        text = "${recipe.totalTimeMinutes} min • ${recipe.difficulty.displayName}",
                                        containerColor = FreshGreenContainer,
                                        contentColor = OnFreshGreenContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}
