package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalOutline
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyAboutScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CharcoalBackground,
        topBar = {
            TopAppBar(
                title = { Text("Privacy Policy & About") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CharcoalBackground,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Card(
                    modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
                    border = BorderStroke(1.dp, CharcoalOutline)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_pantry_chef_logo),
                            contentDescription = "PantryChef AI logo",
                            modifier = Modifier.size(64.dp)
                        )
                        Column {
                            Text(
                                text = "PantryChef AI",
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "Version 1.0 • US & UK Kitchen Companion",
                                style = MaterialTheme.typography.bodySmall,
                                color = FreshGreen
                            )
                        }
                    }
                }
            }

            item {
                PolicySectionCard(
                    title = "Local-First Privacy",
                    body = "PantryChef AI does not require an account or login. Your favourite recipes, recent history, weekly meal plans, shopping lists, dietary choices, and allergies are stored privately on your device. No analytics, tracking SDKs, or advertisements are included."
                )
            }

            item {
                PolicySectionCard(
                    title = "How AI Recipe Generation Works",
                    body = "When you tap 'Generate Recipes', only the ingredients you entered along with your selected meal category, dietary preference, allergy list, and unit preference are sent securely via Firebase AI Logic (protected by Firebase App Check) to generate recipe suggestions. Free-tier usage is limited to 5 AI recipe requests per day."
                )
            }

            item {
                PolicySectionCard(
                    title = "Allergens & Food Safety",
                    body = "AI-generated recipes are automated suggestions and may occasionally miss hidden allergens or cross-contamination risks in packaged foods. PantryChef AI never guarantees a recipe is allergen-free. Always inspect ingredient labels and follow safe food-handling and internal cooking temperature guidelines.",
                    accentOrange = true
                )
            }

            item {
                PolicySectionCard(
                    title = "Nutrition & Unit Conversions",
                    body = "Nutrition figures are rough per-serving estimates and are not medical or clinical dietary advice. Conversions between US Customary and Metric units are rounded for home cooking convenience and clearly labeled as approximate."
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun PolicySectionCard(
    title: String,
    body: String,
    accentOrange: Boolean = false
) {
    Card(
        modifier = Modifier.widthIn(max = 800.dp).fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurfaceElevated),
        border = BorderStroke(1.dp, CharcoalOutline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = if (accentOrange) WarmOrange else FreshGreen
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}
