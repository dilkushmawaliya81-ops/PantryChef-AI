package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.printToString
import com.example.domain.SampleRecipes
import com.example.ui.navigation.PantryChefRoutes
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PantryChefUiRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private fun advanceSplash() {
        composeRule.mainClock.advanceTimeBy(1500)
        composeRule.waitForIdle()
    }

    private fun waitForTag(tag: String) {
        try {
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithTag(tag, useUnmergedTree = true)
                    .fetchSemanticsNodes().isNotEmpty()
            }
        } catch (t: Throwable) {
            val roots = composeRule.onAllNodes(androidx.compose.ui.test.isRoot(), useUnmergedTree = true).fetchSemanticsNodes()
            val nodes = composeRule.onAllNodes(androidx.compose.ui.test.isRoot(), useUnmergedTree = true)
            val tree = (0 until roots.size).joinToString("\n--- ROOT ---\n") { idx ->
                nodes[idx].printToString()
            }
            throw AssertionError("Timed out waiting for tag '$tag'. Roots=${roots.size}\n$tree", t)
        }
    }

    private fun waitForText(text: String) {
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty()
        }
    }

    @Test
    fun `mvp end to end verification across navigation ingredients favourites planner shopping list and units`() {
        advanceSplash()

        // 1. Home: Add & remove ingredients (both chip tap and text input)
        composeRule.onNodeWithText("What's in your kitchen?").assertIsDisplayed()
        composeRule.onNodeWithTag("example_chip_eggs").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("selected_chip_eggs").assertIsDisplayed()

        composeRule.onNodeWithTag("ingredient_input_field").performTextInput("spinach")
        composeRule.onNodeWithTag("add_ingredient_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("selected_chip_spinach").assertIsDisplayed()

        // Remove spinach chip
        composeRule.onNodeWithTag("selected_chip_spinach").performClick()
        composeRule.waitForIdle()
        assertTrue(
            composeRule.onAllNodesWithText("spinach").fetchSemanticsNodes().isEmpty()
        )

        // 2. Discover: Verify sample recipes & open Recipe Detail
        composeRule.onNodeWithTag("bottom_nav_${PantryChefRoutes.DISCOVER}").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Discover Recipes").assertIsDisplayed()

        val firstSample = SampleRecipes.all.first()
        composeRule.onNodeWithTag("recipe_card_${firstSample.id}").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("detail_recipe_title").assertIsDisplayed()

        // 3. Save & remove favourite recipe
        composeRule.onNodeWithTag("detail_favourite_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("detail_back_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("bottom_nav_${PantryChefRoutes.FAVOURITES}").performClick()
        waitForTag("recipe_card_${firstSample.id}")
        composeRule.onNodeWithTag("recipe_card_${firstSample.id}").assertIsDisplayed()

        // Remove from favourites
        composeRule.onNodeWithTag("fav_button_${firstSample.id}").performClick()
        waitForTag("favourites_empty_state")
        composeRule.onNodeWithTag("favourites_empty_state").assertIsDisplayed()

        // 4. Meal Planner: Add and remove meal slot
        composeRule.onNodeWithTag("bottom_nav_${PantryChefRoutes.PLANNER}").performClick()
        waitForTag("planner_empty_state")
        composeRule.onNodeWithTag("planner_empty_state").assertIsDisplayed()

        composeRule.onNodeWithTag("planner_list")
            .performScrollToNode(hasTestTag("planner_add_BREAKFAST"))
        composeRule.onNodeWithTag("planner_add_BREAKFAST").performClick()
        waitForText(firstSample.name)
        composeRule.onNodeWithText(firstSample.name).performClick()

        waitForTag("planner_remove_BREAKFAST")
        composeRule.onNodeWithTag("planner_list")
            .performScrollToNode(hasText(firstSample.name))
        composeRule.onNodeWithText(firstSample.name).assertIsDisplayed()

        composeRule.onNodeWithTag("planner_remove_BREAKFAST").performClick()
        waitForTag("planner_add_BREAKFAST")
        composeRule.onNodeWithTag("planner_list")
            .performScrollToNode(hasTestTag("planner_empty_state"))
        composeRule.onNodeWithTag("planner_empty_state").assertIsDisplayed()
        composeRule.mainClock.advanceTimeBy(5000)
        composeRule.waitForIdle()

        // 5. Shopping List: Add, edit, check, and delete item
        composeRule.onNodeWithTag("bottom_nav_${PantryChefRoutes.SHOPPING}").performClick()
        waitForTag("shopping_list")
        composeRule.onNodeWithTag("shopping_list")
            .performScrollToNode(hasTestTag("shopping_empty_state"))
        composeRule.onNodeWithTag("shopping_empty_state").assertIsDisplayed()

        composeRule.onNodeWithTag("shopping_list").performScrollToNode(hasTestTag("shopping_item_name_input"))
        composeRule.onNodeWithTag("shopping_item_name_input").performTextInput("Avocados")
        composeRule.onNodeWithTag("shopping_item_qty_input").performTextInput("2")
        composeRule.onNodeWithTag("add_shopping_item_button").performClick()

        waitForText("Avocados")
        composeRule.onNodeWithTag("shopping_list").performScrollToNode(hasText("Avocados"))
        composeRule.onNodeWithText("Avocados").assertIsDisplayed()

        // Edit item
        composeRule.onNodeWithTag("shopping_list").performScrollToNode(hasTestTag("shopping_bottom_spacer"))
        composeRule.onNodeWithTag("edit_item_Avocados").assertIsDisplayed().performClick()
        waitForTag("edit_shopping_item_name_input")
        composeRule.onNodeWithTag("edit_shopping_item_name_input").performTextClearance()
        composeRule.onNodeWithTag("edit_shopping_item_name_input").performTextInput("Ripe Avocados")
        composeRule.onNodeWithText("Save").performClick()
        waitForText("Ripe Avocados")
        composeRule.onNodeWithTag("shopping_list").performScrollToNode(hasTestTag("shopping_bottom_spacer"))
        composeRule.onNodeWithText("Ripe Avocados").assertIsDisplayed()

        // Check item
        composeRule.onNodeWithText("Ripe Avocados").performClick()
        waitForText("Clear Purchased Items")
        composeRule.onNodeWithTag("shopping_list").performScrollToNode(hasText("Clear Purchased Items"))
        composeRule.onNodeWithText("Clear Purchased Items").assertIsDisplayed()

        // Delete item
        composeRule.onNodeWithTag("shopping_list")
            .performScrollToNode(hasTestTag("shopping_bottom_spacer"))
        composeRule.onNodeWithTag("delete_item_Ripe Avocados").performClick()
        waitForTag("shopping_empty_state")
        composeRule.onNodeWithTag("shopping_list")
            .performScrollToNode(hasTestTag("shopping_empty_state"))
        composeRule.onNodeWithTag("shopping_empty_state").assertIsDisplayed()

        // 6. Preferences: Switch US Customary <-> Metric
        composeRule.onNodeWithTag("bottom_nav_${PantryChefRoutes.HOME}").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("home_settings_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("pref_unit_METRIC").performClick()
        waitForText("Grams, kilograms, milliliters, liters, °C")
        composeRule.onNodeWithText("Grams, kilograms, milliliters, liters, °C").assertIsDisplayed()

        composeRule.onNodeWithTag("pref_unit_US_CUSTOMARY").performClick()
        waitForText("Cups, tablespoons, teaspoons, ounces, pounds, °F")
        composeRule.onNodeWithText("Cups, tablespoons, teaspoons, ounces, pounds, °F").assertIsDisplayed()
    }
}
