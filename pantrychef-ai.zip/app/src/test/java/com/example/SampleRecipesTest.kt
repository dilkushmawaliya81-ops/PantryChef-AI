package com.example

import com.example.domain.MealCategory
import com.example.domain.SampleRecipes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SampleRecipesTest {

    @Test
    fun `contains exactly 10 complete offline sample recipes`() {
        val recipes = SampleRecipes.all
        assertEquals(10, recipes.size)
        assertEquals(10, recipes.map { it.id }.distinct().size)

        recipes.forEach { recipe ->
            assertTrue("Missing name on ${recipe.id}", recipe.name.isNotBlank())
            assertTrue("Missing description on ${recipe.id}", recipe.description.isNotBlank())
            assertTrue("Invalid prep time on ${recipe.id}", recipe.prepTimeMinutes > 0)
            assertTrue("Invalid cook time on ${recipe.id}", recipe.cookTimeMinutes > 0)
            assertTrue("Invalid servings on ${recipe.id}", recipe.servings in 1..12)
            assertTrue("Missing ingredients on ${recipe.id}", recipe.ingredients.isNotEmpty())
            assertTrue("Missing steps on ${recipe.id}", recipe.steps.isNotEmpty())
            assertTrue("Missing allergens on ${recipe.id}", recipe.allergenInfo.isNotEmpty())
            assertTrue("Missing storage on ${recipe.id}", recipe.storageSuggestions.isNotBlank())
            recipe.ingredients.forEach { ing ->
                assertTrue("Blank ingredient in ${recipe.id}", ing.name.isNotBlank())
                assertTrue("Non-positive ingredient amount in ${recipe.id}", ing.amount > 0.0)
            }
        }

        // Verify all 4 meal categories are covered
        assertTrue(recipes.any { it.mealCategory == MealCategory.BREAKFAST })
        assertTrue(recipes.any { it.mealCategory == MealCategory.LUNCH })
        assertTrue(recipes.any { it.mealCategory == MealCategory.DINNER })
        assertTrue(recipes.any { it.mealCategory == MealCategory.SNACK })
    }
}
