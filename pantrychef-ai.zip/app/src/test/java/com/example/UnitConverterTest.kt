package com.example

import com.example.domain.EnglishVariant
import com.example.domain.MeasurementSystem
import com.example.domain.RecipeIngredient
import com.example.domain.ShoppingCategory
import com.example.domain.UnitConverter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UnitConverterTest {

    @Test
    fun `same unit system scales servings without approximate marker`() {
        val ing = RecipeIngredient("flour", 2.0, "cups", ShoppingCategory.PANTRY)
        val result = UnitConverter.formatIngredient(
            ingredient = ing,
            sourceSystem = MeasurementSystem.US_CUSTOMARY,
            targetSystem = MeasurementSystem.US_CUSTOMARY,
            baseServings = 2,
            targetServings = 4
        )
        assertEquals("4", result.amountText)
        assertEquals("cups", result.unitText)
        assertFalse(result.isApproximateConversion)
    }

    @Test
    fun `us cups to metric ml marks approximate conversion`() {
        val ing = RecipeIngredient("milk", 1.0, "cup", ShoppingCategory.DAIRY)
        val result = UnitConverter.formatIngredient(
            ingredient = ing,
            sourceSystem = MeasurementSystem.US_CUSTOMARY,
            targetSystem = MeasurementSystem.METRIC,
            baseServings = 2,
            targetServings = 2,
            englishVariant = EnglishVariant.UK
        )
        assertTrue(result.isApproximateConversion)
        assertEquals("ml", result.unitText)
        assertTrue(result.fullText.contains("approx."))
    }

    @Test
    fun `metric grams to us ounces converts accurately`() {
        val ing = RecipeIngredient("cheddar cheese", 100.0, "g", ShoppingCategory.DAIRY)
        val result = UnitConverter.formatIngredient(
            ingredient = ing,
            sourceSystem = MeasurementSystem.METRIC,
            targetSystem = MeasurementSystem.US_CUSTOMARY,
            baseServings = 2,
            targetServings = 2
        )
        assertTrue(result.isApproximateConversion)
        assertEquals("oz", result.unitText)
        assertTrue(result.fullText.contains("3 1/2") || result.fullText.contains("3.5"))
    }

    @Test
    fun `temperature conversion converts F to C with approx marker`() {
        val converted = UnitConverter.convertStepTemperatures(
            stepText = "Bake at 350°F for 20 minutes.",
            targetSystem = MeasurementSystem.METRIC
        )
        assertTrue(converted.hasApproximateTemperatureConversion)
        assertTrue(converted.text.contains("175°C (approx.)"))
    }
}
