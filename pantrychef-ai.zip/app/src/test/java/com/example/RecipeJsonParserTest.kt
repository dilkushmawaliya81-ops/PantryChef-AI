package com.example

import com.example.data.ai.RecipeJsonParser
import com.example.domain.DietaryPreference
import com.example.domain.MeasurementSystem
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RecipeJsonParserTest {

    @Test
    fun `parses valid structured recipe json`() {
        val json = """
            {
              "recipes": [
                {
                  "name": "Tomato Herb Omelette",
                  "description": "Quick and fluffy eggs folded with diced tomatoes.",
                  "prepTimeMinutes": 5,
                  "cookTimeMinutes": 8,
                  "servings": 2,
                  "difficulty": "Easy",
                  "mealCategory": "Breakfast",
                  "ingredients": [
                    { "name": "eggs", "amount": 4.0, "unit": "large", "category": "Dairy" },
                    { "name": "tomatoes, diced", "amount": 1.0, "unit": "cup", "category": "Produce" }
                  ],
                  "steps": [
                    "Whisk the eggs in a bowl.",
                    "Cook gently in a non-stick pan and fold over tomatoes."
                  ],
                  "nutrition": {
                    "calories": 240,
                    "proteinGrams": 16,
                    "carbsGrams": 5,
                    "fatGrams": 17,
                    "fiberGrams": 1
                  },
                  "allergenInfo": ["Eggs"],
                  "substitutions": ["Add spinach instead of tomatoes."],
                  "storageSuggestions": "Best enjoyed fresh; refrigerate leftovers up to 1 day."
                }
              ]
            }
        """.trimIndent()

        val recipes = RecipeJsonParser.parseAndValidate(
            jsonString = json,
            measurementSystem = MeasurementSystem.US_CUSTOMARY,
            dietaryTag = DietaryPreference.VEGETARIAN
        )
        assertEquals(1, recipes.size)
        assertEquals("Tomato Herb Omelette", recipes[0].name)
        assertEquals(2, recipes[0].ingredients.size)
        assertEquals(2, recipes[0].steps.size)
    }

    @Test(expected = IllegalStateException::class)
    fun `rejects malformed recipe with missing ingredients and zero servings`() {
        val malformed = """
            {
              "recipes": [
                {
                  "name": "Broken Dish",
                  "description": "Missing ingredients",
                  "prepTimeMinutes": 5,
                  "cookTimeMinutes": 5,
                  "servings": 0,
                  "difficulty": "Easy",
                  "mealCategory": "Dinner",
                  "ingredients": [],
                  "steps": ["Step 1"],
                  "nutrition": { "calories": 100, "proteinGrams": 5, "carbsGrams": 10, "fatGrams": 2, "fiberGrams": 1 },
                  "allergenInfo": [],
                  "substitutions": [],
                  "storageSuggestions": "Store chilled."
                }
              ]
            }
        """.trimIndent()

        RecipeJsonParser.parseAndValidate(
            jsonString = malformed,
            measurementSystem = MeasurementSystem.METRIC,
            dietaryTag = DietaryPreference.NONE
        )
    }
}
