package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.MealPlanEntity
import com.example.data.local.RecipeEntity
import com.example.data.local.RecipeSerialization
import com.example.data.local.ShoppingItemEntity
import com.example.domain.DayOfWeekSlot
import com.example.domain.MealSlotType
import com.example.domain.SampleRecipes
import com.example.domain.ShoppingCategory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PantryChef AI", appName)
    }

    @Test
    fun `room persists favourites meal plan and shopping items`() = runTest {
        val sample = SampleRecipes.all.first()
        database.recipeDao().upsertRecipe(
            RecipeEntity(
                id = sample.id,
                name = sample.name,
                mealCategory = sample.mealCategory.name,
                recipeJson = RecipeSerialization.toJson(sample),
                isFavourite = true,
                isRecentGenerated = false,
                lastViewedAt = 1234L
            )
        )
        val favs = database.recipeDao().observeFavourites().first()
        assertEquals(1, favs.size)
        assertEquals(sample.name, favs.first().name)

        database.mealPlanDao().upsertMealPlan(
            MealPlanEntity(
                id = "${DayOfWeekSlot.MONDAY.name}_${MealSlotType.DINNER.name}",
                dayOfWeek = DayOfWeekSlot.MONDAY.name,
                mealSlot = MealSlotType.DINNER.name,
                recipeId = sample.id,
                recipeName = sample.name,
                mealCategory = sample.mealCategory.name,
                totalTimeMinutes = sample.totalTimeMinutes
            )
        )
        val plans = database.mealPlanDao().observeAllMealPlans().first()
        assertEquals(1, plans.size)

        database.shoppingListDao().upsertItem(
            ShoppingItemEntity(
                id = "item_1",
                name = "Tomatoes",
                quantityText = "2 cups",
                category = ShoppingCategory.PRODUCE.name,
                isChecked = false
            )
        )
        val items = database.shoppingListDao().observeAllItems().first()
        assertEquals(1, items.size)
        assertTrue(items.first().name == "Tomatoes")
    }

    @Test
    fun `meal planner persists across database reopen`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "meal_planner_persistence_test.db"
        context.deleteDatabase(dbName)

        val firstSample = SampleRecipes.all.first()
        val secondSample = SampleRecipes.all[1]

        val db1 = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .allowMainThreadQueries()
            .build()
        db1.mealPlanDao().upsertMealPlan(
            MealPlanEntity(
                id = "${DayOfWeekSlot.TUESDAY.name}_${MealSlotType.BREAKFAST.name}",
                dayOfWeek = DayOfWeekSlot.TUESDAY.name,
                mealSlot = MealSlotType.BREAKFAST.name,
                recipeId = firstSample.id,
                recipeName = firstSample.name,
                mealCategory = firstSample.mealCategory.name,
                totalTimeMinutes = firstSample.totalTimeMinutes
            )
        )
        // Replace existing slot entry
        db1.mealPlanDao().upsertMealPlan(
            MealPlanEntity(
                id = "${DayOfWeekSlot.TUESDAY.name}_${MealSlotType.BREAKFAST.name}",
                dayOfWeek = DayOfWeekSlot.TUESDAY.name,
                mealSlot = MealSlotType.BREAKFAST.name,
                recipeId = secondSample.id,
                recipeName = secondSample.name,
                mealCategory = secondSample.mealCategory.name,
                totalTimeMinutes = secondSample.totalTimeMinutes
            )
        )
        db1.close()

        val db2 = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .allowMainThreadQueries()
            .build()
        val reloaded = db2.mealPlanDao().observeAllMealPlans().first()
        assertEquals(1, reloaded.size)
        assertEquals(secondSample.id, reloaded.first().recipeId)
        assertEquals(secondSample.name, reloaded.first().recipeName)
        db2.mealPlanDao().deleteMealSlot(DayOfWeekSlot.TUESDAY.name, MealSlotType.BREAKFAST.name)
        assertEquals(0, db2.mealPlanDao().observeAllMealPlans().first().size)
        db2.close()
        context.deleteDatabase(dbName)
    }
}
